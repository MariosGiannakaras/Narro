import importlib.util,re
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=30
s=c.cli('snapshot');m=re.findall(r'- textbox "Title"[^\r\n]*\[ref=(e\d+)\]',s)
if len(m)!=1:raise RuntimeError('Expected list title')
c.cli('fill',m[0],'Isolated alert capture');c.button('Create',keyboard=True);c.button('Settings',keyboard=True);s=c.cli('snapshot');print('\n'.join(x for x in s.splitlines() if any(v in x for v in ['Timed task alerts','Animated timer flash','Pomodoros','Close preferences','Task alert interval','option "5 mins"'])))
