import importlib.util,re,time,datetime,json,os
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=120
s=c.cli('snapshot');m=re.findall(r'button "Make live: Isolated timed alert capture"[^\r\n]*\[ref=(e\d+)\]',s)
if len(m)!=1:raise RuntimeError('Expected actual Make live button')
t=time.monotonic();c.journal('START clean no-estimate task through actual Make live',ref=m[0],watcherPid=os.getpid());c.cli('click',m[0]);c.cli('run-code','async(page)=>{await page.mouse.move(10,680);}')
s=c.cli('snapshot');(p/'countup-before-wait.txt').write_text(s,encoding='utf-8')
if 'Pomodoro' in s:raise RuntimeError('Clean fixture unexpectedly still Pomodoro; no isolated claim')
(p/'scheduled-capture.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'watcherPid':os.getpid(),'recordAtSecondsAfterClick':250,'recordDurationSeconds':80,'actualAlertIntervalSeconds':300,'purpose':'No desktop video during initial4min quiet task; no source/product changes'},indent=2))
print('Clean count-up started; recording scheduled at250s; no recorder during quiet wait',flush=True)
time.sleep(max(0,250-(time.monotonic()-t)))
def run():
 c.journal('Isolated alert observation: no input, hover, task or presentation switch during80s capture');time.sleep(80)
c.record('R4-isolated-alert',run)
c.cli('snapshot');print('R4 captured and recorder stopped',flush=True)
