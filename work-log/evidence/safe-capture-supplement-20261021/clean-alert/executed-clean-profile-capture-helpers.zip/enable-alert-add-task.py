import importlib.util,re
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=60
for label in ['Timed task alerts','Animated timer flash']:
 s=c.cli('snapshot');rows=[x for x in s.splitlines() if '- switch "'+label+'"' in x]
 if len(rows)!=1:raise RuntimeError('Expected switch '+label)
 if '[checked]' not in rows[0]:
  ref=re.search(r'\[ref=(e\d+)\]',rows[0]).group(1);c.journal('UI enable '+label,ref=ref);c.cli('click',ref)
s=c.cli('snapshot')
if '- combobox "Task alert interval"' not in s:raise RuntimeError('Expected interval control')
c.cli('run-code','async(page)=>{await page.getByRole("combobox",{name:"Task alert interval",exact:true}).selectOption({label:"5 mins"});}')
c.journal('UI minimum5min alert configured; Pomodoros observed unchecked; no SQL override')
c.cli('press','Escape');c.cli('tab-select','1');c.cli('run-code','async(page)=>{await page.emulateMedia({reducedMotion:"no-preference"});}');c.cli('--raw','eval','async()=>{await window.__TAURI_INTERNALS__.invoke("focus_surface_show");return true;}');c.button('Add task in Focus Panel',keyboard=True)
s=c.cli('snapshot');m=re.findall(r'- textbox "Task title"[^\r\n]*\[ref=(e\d+)\]',s)
if len(m)!=1:raise RuntimeError('Expected task title')
c.cli('fill',m[0],'Isolated timed alert capture');c.button('Add task',keyboard=True);s=c.cli('snapshot');print('\n'.join(x for x in s.splitlines() if any(v in x for v in ['button','Isolated','elapsed','Pomodoro','count','Count'])))
