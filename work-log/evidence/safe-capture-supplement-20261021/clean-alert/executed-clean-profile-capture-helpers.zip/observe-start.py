import importlib.util,re
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=100
s=c.cli('snapshot');a=re.findall(r'- article \[ref=(e\d+)\]',s)
if not a:raise RuntimeError('Expected task')
c.cli('hover',a[0]);s=c.cli('snapshot');print('\n'.join(x for x in s.splitlines() if 'button' in x))
