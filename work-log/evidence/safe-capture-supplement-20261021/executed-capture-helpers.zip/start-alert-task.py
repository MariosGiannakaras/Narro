import importlib.util,re
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=800
snap=c.cli('snapshot');m=re.findall(r'- textbox "Task title"[^\r\n]*\[ref=(e\d+)\]',snap)
if len(m)!=1:raise RuntimeError('Expected new task title')
c.cli('fill',m[0],'Isolated timer flash capture — no estimate');c.button('Add task',keyboard=True);c.button('Skip task',keyboard=True);snap=c.cli('snapshot');print('\n'.join(x for x in snap.splitlines() if any(v in x for v in ['button','remaining','elapsed','Isolated','Pomodoro','Time Taken'])))
