from pathlib import Path
import subprocess,json,datetime,time,ctypes,re,shutil
R=Path(__file__).resolve().parent
NODE=shutil.which('node');NPX=r'C:\Users\MariosG\AppData\Roaming\npm\node_modules\npm\bin\npx-cli.js'
serial=0
def journal(action,**kw):
 with (R/'actions.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),action=action,**kw))+'\n')
def cli(*args):
 global serial
 serial+=1;p=subprocess.run([NODE,NPX,'--yes','--package','@playwright/cli','playwright-cli','-s=narroSafe',*args],capture_output=True,text=True,encoding='utf-8',timeout=20)
 (R/f'cli-{serial:03d}.txt').write_text(p.stdout+p.stderr,encoding='utf-8')
 if p.returncode or p.stdout.startswith('### Error'):raise RuntimeError('CLI failed; see receipt '+str(serial))
 return p.stdout

def button(name,keyboard=False):
 snap=cli('snapshot');matches=re.findall(r'- button "'+re.escape(name)+r'"[^\r\n]*\[ref=(e\d+)\]',snap)
 if len(matches)!=1:raise RuntimeError('Expected one current visible button '+name+'; got '+str(len(matches)))
 journal('BEGIN button '+name,input='CDP keyboard' if keyboard else 'CDP pointer',ref=matches[0])
 if keyboard:cli('run-code','async (page) => { const b=page.getByRole("button",{name:'+json.dumps(name)+',exact:true}); await b.focus(); await b.press("Space"); }')
 else:cli('click',matches[0])
 journal('RETURN button '+name)

def windows():
 u=ctypes.windll.user32;pid=54968;result=[]
 @ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
 def visit(h,l):
  p=ctypes.c_ulong();u.GetWindowThreadProcessId(ctypes.c_void_p(h),ctypes.byref(p))
  if p.value==pid:
   title=ctypes.create_unicode_buffer(512);u.GetWindowTextW(ctypes.c_void_p(h),title,512)
   if title.value=='Narro - Focus':result.append(h)
  return True
 u.EnumWindows(visit,0)
 if len(result)!=1:raise RuntimeError('Expected exactly one owned Focus HWND')
 return result[0]
class Rect(ctypes.Structure):_fields_=[('left',ctypes.c_long),('top',ctypes.c_long),('right',ctypes.c_long),('bottom',ctypes.c_long)]
def geometry(move=None):
 u=ctypes.windll.user32;h=windows();area=Rect();u.SystemParametersInfoW(48,0,ctypes.byref(area),0)
 if move is not None:
  x,y=move(area)
  if not u.SetWindowPos(ctypes.c_void_p(h),None,x,y,0,0,0x15):raise ctypes.WinError()
  time.sleep(.4)
 b=Rect();u.GetWindowRect(ctypes.c_void_p(h),ctypes.byref(b));v={'hwnd':h,'bounds':[b.left,b.top,b.right,b.bottom],'workArea':[area.left,area.top,area.right,area.bottom],'diagnosticPlacementNotOSDrag':move is not None};journal('NATIVE_GEOMETRY',**v);return v

def record(name,fn):
 d=R/name;d.mkdir(exist_ok=False);err=(d/'ffmpeg-stderr.txt').open('w');ff=subprocess.Popen([shutil.which('ffmpeg'),'-hide_banner','-loglevel','warning','-f','lavfi','-i','ddagrab=output_idx=0:framerate=60:draw_mouse=1','-vf','hwdownload,format=bgra','-t','180','-c:v','libx264','-preset','ultrafast','-crf','18','-pix_fmt','yuv420p',str(d/'native-original.mkv')],stdin=subprocess.PIPE,stderr=err,stdout=subprocess.DEVNULL)
 try:
  time.sleep(.7)
  if ff.poll() is not None:raise RuntimeError('Recorder failed before actions')
  journal('RECORD_START',segment=name,pid=ff.pid);fn();time.sleep(1)
 finally:
  if ff.poll() is None:
   try:ff.communicate(b'q\n',timeout=5)
   except subprocess.TimeoutExpired:ff.kill();ff.wait();journal('RECORDER_FORCED_STOP',segment=name)
  err.close();journal('RECORD_STOP',segment=name,exitCode=ff.returncode)
 p=subprocess.run([shutil.which('ffprobe'),'-v','error','-count_frames','-show_entries','stream=width,height,nb_read_frames,r_frame_rate:format=duration','-of','json',str(d/'native-original.mkv')],capture_output=True,text=True);(d/'video-metadata.json').write_text(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError('Video did not finalize')
