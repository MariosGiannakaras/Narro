import importlib.util,re,json
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=200

def run():
 c.button('Notes',keyboard=True);c.button('Open larger notes editor',keyboard=True)
 snap=c.cli('snapshot');m=re.findall(r'- textbox "Task note"[^\r\n]*\[ref=(e\d+)\]',snap)
 if len(m)!=1:raise RuntimeError('Expected actual Task note textbox')
 c.journal('TYPE owned synthetic note',ref=m[0]);c.cli('fill',m[0],'Remaining acquisition: larger Notes editor, keyboard return, saved content.');c.cli('screenshot','--filename',str(p/'notes-large-webview.png'));c.journal('ESCAPE from observed Task note editor');c.cli('press','Escape');c.cli('snapshot');c.button('Save note',keyboard=True);c.cli('snapshot');c.cli('screenshot','--filename',str(p/'notes-after-save-webview.png'))
c.record('R2-larger-notes',run)
print('R2 acquisition frozen; no visual PASS analysis')
