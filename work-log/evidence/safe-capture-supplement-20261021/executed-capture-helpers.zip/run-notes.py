import importlib.util,time
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=100
c.geometry(lambda a:(a.right-350,150));c.button('Expand Floating Timer',keyboard=True)
print(c.cli('snapshot'))
