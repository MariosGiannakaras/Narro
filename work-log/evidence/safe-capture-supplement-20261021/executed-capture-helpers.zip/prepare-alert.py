import importlib.util
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=500
c.button('Home',keyboard=True);c.cli('tab-select','1');c.button('Settings',keyboard=True);print(c.cli('snapshot'))
