import importlib.util
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=600
c.journal('Actual Preferences interval minimum5min; no unsupported60s value injected')
c.cli('press','Escape');c.cli('tab-select','0');c.cli('--raw','eval','async()=>{await window.__TAURI_INTERNALS__.invoke("focus_surface_show");return true;}');snap=c.cli('snapshot');print('\n'.join(x for x in snap.splitlines() if any(v in x for v in ['button','remaining','success','Success','textbox'])))
