import importlib.util
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
c.journal('SETUP no settings SQL edits; verified accepted main EXE; CDP actual WebView2 not OS input')
c.cli('run-code','async(page)=>{await page.emulateMedia({reducedMotion:"no-preference"});}')
c.button('Compact view')
def run():
 c.geometry(lambda a:(a.right-350,a.bottom-114));c.button('Expand Floating Timer',keyboard=True);c.geometry();c.cli('screenshot','--filename',str(p/'bottom-expanded-webview.png'));c.button('Collapse Floating Timer',keyboard=True);c.geometry()
c.record('R1-bottom',run)
print('R1 acquisition frozen; no visual PASS analysis')
