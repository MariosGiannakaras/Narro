import importlib.util
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=700
c.button('Pause',keyboard=True);c.button('Add task in Focus Panel',keyboard=True);snap=c.cli('snapshot');print('\n'.join(x for x in snap.splitlines() if any(v in x for v in ['button','textbox','combobox','dialog','spinbutton'])))
