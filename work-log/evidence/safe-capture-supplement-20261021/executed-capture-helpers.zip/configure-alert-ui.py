import importlib.util,re
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=900
c.button('Pause',keyboard=True);c.button('Preferences',keyboard=True)
for i in range(2):
 snap=c.cli('snapshot');m=re.findall(r'- switch "Pomodoros"[^\r\n]*\[ref=(e\d+)\]',snap)
 if len(m)!=1:raise RuntimeError('Expected actual Pomodoros switch')
 c.journal('Pomodoros actual UI toggle',ref=m[0],iteration=i);c.cli('click',m[0])
c.button('Back to Focus',keyboard=True);print('\n'.join(x for x in c.cli('snapshot').splitlines() if any(v in x for v in ['Pomodoro','remaining','button "Resume','Time Taken'])))
