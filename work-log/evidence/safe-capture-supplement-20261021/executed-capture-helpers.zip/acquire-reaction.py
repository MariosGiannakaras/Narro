import importlib.util,re,time
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=400
snap=c.cli('snapshot');m=re.findall(r'- switch "Fun gif on success screen"[^\r\n]*\[ref=(e\d+)\]',snap)
if len(m)!=1:raise RuntimeError('Expected real Fun gif switch')
c.journal('SET Fun gif ON through real UI switch; owned profile only',ref=m[0]);c.cli('click',m[0]);c.button('Back to Focus',keyboard=True)
def run():
 snap=c.cli('snapshot');a=re.findall(r'- article \[ref=(e\d+)\]',snap)
 if not a:raise RuntimeError('Expected live card')
 c.cli('hover',a[0]);c.button('Complete task',keyboard=True);time.sleep(5);c.cli('snapshot');c.cli('screenshot','--filename',str(p/'reaction-webview.png'))
c.record('R3-normal-reaction',run)
print('R3 acquisition frozen; no visual PASS analysis')
