from pathlib import Path
import importlib.util,time,sys
r=Path(__file__).parent;s=importlib.util.spec_from_file_location('c',r/'capture-helper.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
name=sys.argv[1]
def wait():
 end=time.monotonic()+165
 while time.monotonic()<end and not (r/(name+'.stop')).exists():time.sleep(.25)
c.record(name,wait)
