# PR357 physical evidence reuse matrix — planned, no PASS yet

Before capture: current authoritative main HANDOFF/TODO/audit crosswalk inspected; M1-M4=4/10, M5-M9 acceptance open, M10blocked. Existing PA01-08 scoped evidence remains retained. Current two monitors are active: primaryDISPLAY1[0,0,2560,1080]96DPI and secondaryDISPLAY2[-1920,0,0,1080]120DPI. OBS remains existing4480x1080/60 two-screen scene and is not recording during preparation.

| Existing gate/claim | Intended adequate exercise | Pre-capture status / reuse limit |
| --- | --- | --- |
| M5 P3-M5-04/B48 | Actual task menu→Delete retained Confirm/X→Cancel/Escape/reopen, primary100 and secondary125, both themes when practical; stable geometry and opaque background in continuous recording | OPEN; local4/4 DOM/static review alone not nativePASS |
| M5 U28/B52 | Actual inline Title/EST form and repeated create, normal/focus/disabled/Cancel states | OPEN for the changed label/source grammar; approved Create/EditList picker unaffected |
| M5 U39/B61 | Owned empty individual list shows AllClear in all four lanes, Done has no create | OPEN for changed Done copy; do not infer every scheduling subgroup state |
| M5 U25/B47 + adjacent B46 repeat entry | Actual bottom Video→RecordVoice, retain/reset same form and focus; explicit top entry, visible newest-first and durable independent IDs after Quit | OPEN; no renderer fixture substitute for durable native commit |
| M5 Home/list-create surfaces encountered | Record real open/create/back and list preview if actually used; compare only clearly exercised controls/states | Supplement only; no complete Home/picker/image/218icon parity from appearance |
| M5 U24/B44 | Only if an actual controlled lane transfer/count sequence is deliberately exercised | Source conflict disposition resolved; otherwise rendered/native gate staysOPEN |
| M5 U36/B70 | Known next source fix, not part of current implementation | NOTRUN; do not consume capture time re-demonstrating an unchanged known mismatch |
| M1 display/window/performance | Main100→125 movement can supply DPI observations only | No Focus topology/topmost/performance re-run or new claim; earlier scoped evidence retained |
| M6/M7 Focus/Timer | No planned Focus/task-session path; unchanged accepted native/runtime source | NOTEXERCISED; new M7 logger may say INCONCLUSIVE for unrequested C5, not revoke prior scoped C5PASS |
| M8 theme preference | Actual theme save/reopen when used, focus/Escape restoration only when exercised | Supplemental same-session evidence, not full Preferences/shortcuts/notification acceptance |
| M9 Reports | No planned Reports workflow | NOTEXERCISED; M9export12/12 retained separately |
| M10 | Evidence may be reusable later | No checkbox/counter advances before hard entry gate |

After capture: disposition each exercised row with exact video/action/UIA/HWND/DB/source pointers; keep insufficient statesOPEN/NOTRUN and append observedFAIL timestamps. Freeze complete raw evidence before aggregate review. Preserve original profile/OS settings/topology and publish whole Narro-M7-Logs; private backup/profile ledger stay local.
