from pathlib import Path
import importlib.util,time
r=Path(__file__).parent;s=importlib.util.spec_from_file_location('c',r/'capture-helper.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
def wait():
 deadline=time.monotonic()+115
 while time.monotonic()<deadline and not (r/'native-segment-stop.flag').exists():time.sleep(.4)
c.record('B01-native-main-input',wait)
