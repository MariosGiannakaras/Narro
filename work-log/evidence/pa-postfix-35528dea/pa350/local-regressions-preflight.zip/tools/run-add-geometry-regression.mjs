import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
const label=process.argv[2];const root='E:/SystemFiles/Desktop/Narro-PA-postfix-20261013';
const out=spawnSync('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',[
 '--headless','--disable-gpu','--no-first-run','--window-size=1920,1080',`--user-data-dir=${root}/geometry-edge-${label}-${Date.now()}`,
 '--virtual-time-budget=10000','--dump-dom','http://127.0.0.1:1420/focus-editor-fixture.html?scenario=m7-integration&theme=dark&motion=true'
],{windowsHide:true,encoding:'utf8',timeout:45000,maxBuffer:10*1024*1024});
fs.writeFileSync(`${root}/analysis/add-geometry-${label}.html`,out.stdout??'');
fs.writeFileSync(`${root}/analysis/add-geometry-${label}.log`,out.stderr??'');
const html=out.stdout??'';const script=html.match(/<script[^>]*id="focus-editor-contract"[^>]*>([\s\S]*?)<\/script>/)?.[1];
const contract=script?JSON.parse(script):null;const pass=contract?.focusAddEditorFullyVisible===true;
console.log(JSON.stringify({label,status:out.status,bytes:html.length,pass,contract}));if(out.status!==0||!pass)process.exitCode=1;


