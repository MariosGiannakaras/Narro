# Post-correction physical capture order

Before launch: verify exact resulting-main/package/EXE SHA, original DB/profile fingerprint, backups and owned profile namespace; preserve primary UltraGear100 and LG125 extended topology; OBS both4480x1080 with verified loopback. No real user data in evidence. No M11/live Blitzit.

1. Startup/recovery and HWND/source identity. Record system display/UIA/HWND/log facts.
2. PA01: paused-session3 Panel↔compact pairs on same100% monitor,3 compact↔expanded; drag Timer onto LG125 then3 Panel↔Timer pairs across selected primary100/125. Repeat paired reduced-motion observations. Preserve session/time IDs. Bookmark possible defects and continue.
3. PA03: real short EST deadline, Time's Up compact/expanded, Extend and Pause; exact labels and complete controls. Reuse applicable M6/M7 states.
4. PA04: real Reports Add from toolbar and task detail; a no-data EXCLUSIVE4s lock while actual Add/Escape/Tab/ShiftTab occur, read-only UIA focus probe; exactly one durable owned insertion and correct opener after completion. Long title, tooltip, date/time inputs and three summary cards remain bounded. No source debug during recording.
5. PA05: named LG selection/side, actual Windows Display2 DPI125→100→125 using genuine Settings; retained selection, safe Timer/Panel and no offscreen/blank behavior. Real logical disconnect/recovery only if independent state remains safe. Physical HDMI unplug is distinct and cannot be simulated.
6. PA06: actual Preview/mute/unmute/volume, real short due work/break alert with foreground/background; record actual Windows audio/toast. Test OS Focus assist effect only as a declared state; do not mistake recorder health for Narro sound PASS.
7. PA07: fresh ≥64px real drag, normal tray Quit, same EXE hash relaunch and paused recovery/position. Save evaluator's completed result before unrelated later Quit overwrites latest progress.
8. PA08: exact standalone already exercised; safe owned-path NSIS install/launch and old verified baseline→new verified package upgrade/persistence if independent. MSI is blocked by Computer Use policy, no bypass. Use only disposable profile.

After useful segment: stop capture, freeze full media/logs/screens/HWND/UIA plus chronological manifest and protected restoration proof; inspect current M1–M9 open-gate matrix, disposition only actually exercised requirements; aggregate analysis. Quiet floating-only CPU/memory60s (Main destroyed/closed, OBS not recording) is a separate measurement. No M10 counters.

Counters are protocol groups acquired/reviewed separately from exact-binary PASS/FAIL/UNCERTAIN/NOT RUN and corrected-family acceptance. No PASS from UI appearance alone.