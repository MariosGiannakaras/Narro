from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
session=Path(__file__).parent.resolve()
home=Path.home()
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')
processes=json.loads(subprocess.check_output(['powershell','-NoLogo','-NoProfile','-Command',
    "@(Get-Process narro,narro-m7-validation -ErrorAction SilentlyContinue | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],encoding='utf-8',creationflags=0x08000000) or '[]')
assert not processes, 'Refuse to isolate a running Narro profile'
ledger=[]
for kind in ['Roaming','Local']:
    base=(home/'AppData'/kind).resolve()
    active=base/'com.mariosg.Narro'
    retained=base/'com.mariosg.Narro.PA-test-retained-20261013'
    protected=base/('com.mariosg.Narro.PA-postfix-protected-'+stamp)
    assert active.resolve().parent==base and retained.resolve().parent==base and protected.parent==base
    assert active.is_dir() and retained.is_dir() and not protected.exists()
    assert not active.is_symlink() and not retained.is_symlink()
    ledger.append({'kind':kind,'active':str(active),'retained':str(retained),'protected':str(protected)})
original_db=Path(ledger[0]['active'])/'narro.db'
expected=hashlib.sha256(original_db.read_bytes()).hexdigest()
assert expected=='3b98e19d94ebcc75bd5d10f8fda0d17038a2aac6086782b44d76509f0e0636c4', 'Original profile changed; preserve and inspect before isolation'
state={'sessionRoot':str(session),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalDbSha256':expected,'namespaces':ledger,'state':'PREPARED'}
path=session/'profile-protection-private.json'
assert not path.exists(), 'Preserve an existing protection ledger'
path.write_text(json.dumps(state,indent=2),encoding='utf-8')
for item in ledger:
    active=Path(item['active']);protected=Path(item['protected'])
    active.rename(protected)
    state['state']='ORIGINAL_PROTECTED_'+item['kind']
    path.write_text(json.dumps(state,indent=2),encoding='utf-8')
    shutil.copytree(item['retained'],active)
    (active/'pa-owned-profile.json').write_text(json.dumps({'sessionRoot':str(session),'owned':True,'utc':state['utc']}),encoding='utf-8')
state['state']='OWNED_PROFILE_ACTIVE'
path.write_text(json.dumps(state,indent=2),encoding='utf-8')
print(json.dumps({'state':state['state'],'originalDbSha256':expected,'sessionRoot':str(session)}))
