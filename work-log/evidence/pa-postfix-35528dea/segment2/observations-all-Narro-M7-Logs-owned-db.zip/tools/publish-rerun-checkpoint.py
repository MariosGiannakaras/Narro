from pathlib import Path
import datetime,hashlib,json,zipfile,subprocess
repo=Path(r'C:\Users\MariosG\.codex\worktrees\m7-native-paint\NarroUpload');root=Path(__file__).resolve().parent.parent
dest=repo/'work-log/evidence/pa01-08-20261013/corrections';dest.mkdir(parents=True,exist_ok=True)
run=json.loads(subprocess.check_output(['gh','api','repos/MariosGiannakaras/Narro/actions/runs/38384969271'],encoding='utf-8'))
assert run['head_sha']=='35528dea615e28b146d5eb808cc9432582184738' and run['run_attempt']==2
bundle=dest/'pr349-main-rerun-and-fresh-physical-tools.zip';assert not bundle.exists()
inputs=[root/'analysis/ci-main-attempt1-cancelled.log',root/'PA04-lock.py',root/'native-input.py',root/'tools/verify-main-artifact.py']
entries=[]
with zipfile.ZipFile(bundle,'x',zipfile.ZIP_DEFLATED) as z:
 for file in inputs:
  data=file.read_bytes();member=file.relative_to(root).as_posix();z.writestr(member,data);entries.append({'path':member,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run':run['id'],'source':run['head_sha'],'attempt':run['run_attempt'],'status':run['status'],'conclusion':run['conclusion'],'bundle':bundle.name,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'entries':entries,'native_acceptance':'0/3; NOT RUN on corrected executable','original_profile_sha256':'3b98e19d94ebcc75bd5d10f8fda0d17038a2aac6086782b44d76509f0e0636c4','helper_status':'syntax compiled only; no input, DB lock or launch executed'}
(dest/'pr349-main-rerun-checkpoint.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
note=f'''# PR349 resulting-main attempt1 cancelled; exact-source attempt2 dispatched

[CI38384969271](https://github.com/MariosGiannakaras/Narro/actions/runs/38384969271) attempt1 was CANCELLED at2026-10-13T11:00:45Z. Actual Windows log shows Rust suites passed and visual artifact upload completed; Build Tauri Release then reports operation cancelled. Later packaged-runtime artifact upload reports no files because that stage was not completed. This is not a completed Windows PASS and does not establish a product failure; cancellation cause is not attributed without evidence.

Exact-source rerun dispatched, now attempt2 **{run['status'].upper()}**, source35528dea615e28b146d5eb808cc9432582184738. Original PR349 CI remains3/3 SUCCESS; source merge remains25/25 matching blobs. [Rerun and preparation manifest](evidence/pa01-08-20261013/corrections/pr349-main-rerun-checkpoint.json), [full cancelled Windows log and fresh helper snapshots](evidence/pa01-08-20261013/corrections/pr349-main-rerun-and-fresh-physical-tools.zip). The separate peer PR348 resulting-main run was observed on attempt2; do not restart or take over that other owner. No source changes or duplicated build trigger from this evidence publication.

Prepared PA04 helper now requires the fresh actual Main HWND, foreground Narro and an owned-profile marker/protection state, uses a no-data4s EXCLUSIVE transaction with rollback and read-only native UIA, and emits actual input timestamps. Per-input screenshots are suppressed only inside this timed protocol to avoid consuming the lock interval with ffmpeg; continuous OBS records the interval. Prepared production/visual artifact verifier checks provider digest, all ZIP CRC/member paths, PE/CFB headers, x64 standalone and rendered Reports assertions. Both helpers only syntax-compiled, not physically executed. These ZIP-contained snapshots are evidence/continuation inputs, not build/test configuration.

Current safety: no Narro process, original profiles remain restored; original DB hash reconfirmed3b98e19d94ebcc75bd5d10f8fda0d17038a2aac6086782b44d76509f0e0636c4. OBS/Settings actual windows observed; no new recording, isolation or corrected launch. No original user data or private protection ledger uploaded.

Counters: acquisition8/8, aggregate triage8/8, frozen baseline1PASS/3FAIL/4UNCERTAIN; corrected physical0/3. Mandatory3/10, M10 hard entry blocked, M11/live Blitzit excluded. ONE NEXT: wait for exact attempt2 and validate resulting-main production/visual artifacts before the prepared owned-profile continuous Windows capture. All current actions and remaining physical requirements are now published; historical pending-attempt1 text is superseded by this checkpoint.
'''
(repo/'work-log/2026-10-13-pa349-main-rerun-physical-handoff.md').write_text(note,encoding='utf-8')
line=f'**Current PA continuation:** resulting-main CI38384969271 attempt1 CANCELLED; exact35528dea attempt2 **{run["status"].upper()}**. [Uploaded full cancellation log, fresh guarded PA04 tools and one next action](work-log/2026-10-13-pa349-main-rerun-physical-handoff.md). Acquisition8/8, analysis8/8, corrected physical0/3; no corrected launch/capture, original profiles restored. Complete attempt2 and verify package before owned-profile capture.\n\n'
for name in ('HANDOFF.md','TODO.md','STATUS.md'):
 file=repo/name;s=file.read_text(encoding='utf-8');pos=s.index('\n')+1;s=s[:pos]+'\n'+line+s[pos:]
 # Preserve previous checkpoints, but the single next-action owner must reflect current CI.
 begin=s.find('**One next action:** PR349 MERGED')
 if begin!=-1:
  end=s.find('\n\n',begin);s=s[:begin]+'**One next action:** finish exact resulting-main CI38384969271 attempt2 (attempt1 CANCELLED), verify package/source hashes, then run the prepared owned-profile physical capture. PR349 already merged35528dea; do not duplicate it. Corrected physical0/3. [Latest exact continuation](work-log/2026-10-13-pa349-main-rerun-physical-handoff.md).'+s[end:]
 file.write_text(s,encoding='utf-8')
for name in ('docs/CURRENT_WINDOWS_RESIDUAL_PHYSICAL_SESSION.md','docs/AUDIT_IMPLEMENTATION_CROSSWALK.md'):
 file=repo/name;s=file.read_text(encoding='utf-8');pos=s.index('\n')+1
 s=s[:pos]+'\n'+line.replace('work-log/','../work-log/')+s[pos:]
 if 'CURRENT_WINDOWS' in name:s=s.replace('## CURRENT 2026-10-12 — U04 newest exact resulting-main Windows release, true fourhash pinned; native PA USER-PAUSED','## HISTORICAL 2026-10-12 — U04 frozen baseline pin; superseded continuation')
 file.write_text(s,encoding='utf-8')
print(json.dumps({'run_attempt':run['run_attempt'],'status':run['status'],'bundle_sha256':record['bundle_sha256'],'bundle_bytes':bundle.stat().st_size}))
