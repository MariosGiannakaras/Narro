from pathlib import Path
import json,hashlib,zipfile,sqlite3,subprocess,datetime
root=Path(__file__).resolve().parent.parent;repo=Path(r'C:\Users\MariosG\.codex\worktrees\m7-native-paint\NarroUpload')
freeze=root/'freeze-segment2';freeze.mkdir(exist_ok=True)
db=Path.home()/'AppData/Roaming/com.mariosg.Narro/narro.db'
if not (freeze/'owned-profile.db').exists():
 assert json.loads((db.parent/'pa-owned-profile.json').read_text())['sessionRoot']==str(root)
 a=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True);b=sqlite3.connect(freeze/'owned-profile.db');a.backup(b);assert b.execute('pragma integrity_check').fetchone()[0]=='ok';b.close();a.close()
video=Path(r'E:\SystemFiles\Desktop\NarroUpload\artifacts\m7-pr234-native-20261005\video\2026-10-13 17-04-20.mkv')
probe=r'E:\SystemFiles\Desktop\NarroUpload\artifacts\ui-validation-tools\ffmpeg-portable\ffmpeg-9.0.2-essentials_build\bin\ffprobe.exe'
meta=json.loads(subprocess.check_output([probe,'-v','error','-show_entries','format=duration,size:stream=index,codec_name,codec_type,width,height,r_frame_rate,sample_rate,channels','-of','json',str(video)],encoding='utf8'))
assert any(s.get('width')==4480 and s.get('height')==1080 for s in meta['streams'])
dest=repo/'work-log/evidence/pa-postfix-35528dea/segment2';dest.mkdir(parents=True,exist_ok=True)
raw=dest/'observations-all-Narro-M7-Logs-owned-db.zip';assert not raw.exists()
inputs=list((root/'observations').glob('*'))+list(root.glob('*.py'))+list((root/'tools').glob('*.py'))+list((root/'package/Narro-M7-Logs').rglob('*'))+[freeze/'owned-profile.db']
inputs += [root/x for x in ('CAPTURE_ORDER.md','actions.jsonl','native-actions.jsonl','key-dispatch.jsonl','motion-original.json','motion-normal.json','motion-reduced.json','motion-repeat-normal.json','original-profile-restoration-proof.json','motion-restore.json') if (root/x).exists()]
entries=[]
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(set(inputs)):
  if not f.is_file():continue
  member=f.relative_to(root).as_posix();data=f.read_bytes();z.writestr(member,data);entries.append({'path':member,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(raw) as z:assert z.testzip() is None
parts=[];whole=hashlib.sha256()
with video.open('rb') as f:
 n=1
 while block:=f.read(48*1024*1024):
  name=f'continuous.mkv.part{n:03d}';p=dest/name;assert not p.exists();p.write_bytes(block);whole.update(block);parts.append({'path':name,'bytes':len(block),'sha256':hashlib.sha256(block).hexdigest()});n+=1
manifest={'freeze_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'35528dea615e28b146d5eb808cc9432582184738','ci':38384969271,'attempt':2,'standalone_exe_sha256':'cc36f832b7db7a5c09a1d87cc1b581b32af7680bdff079093db36db1a41856f8','old_installed_exe_sha256':'884a7926b3ee86db9cd3aff2df62d2abf89cb48fdd965410be5b8a4a20d0b72d','new_installed_exe_sha256':'f50f3d9334c42238c91b385a944dcafe4b2c7a50edf7d71c7e18dc3db1a6c190','video':{'original_name':video.name,'start_utc':'2026-10-13T14:04:19.938Z','stop_utc':'2026-10-13T15:09:04.262Z','sha256':whole.hexdigest(),'metadata':meta,'parts':parts,'reassembly':'Concatenate parts in numeric order as binary bytes; verify whole SHA256 before decoding.'},'raw_bundle':{'path':raw.name,'sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'entries':entries},'counter':'Available primary acquisition8/8; aggregate analysis0/8; corrected overall native0/3. C5 placement restart independently PASS.','limits':['Physical HDMI unplug NOT RUN; logical /internal followed by duplicate then extend is recorded separately.','MSI policy blocked NOT RUN; no bypass.','Same-version earlier-build NSIS maintenance reinstall exercised, not schema-crossing migration or autostart acceptance.','Focus assist ON during real break; notification delivery/audio requires encoded recording and logs review.','No aggregate visual PASS inferred from UIA or isolated stills.','Recording contains navigation/recovery delays; exact actions retained for targeted review.'],'profile':'Owned test DB only; original user profiles and private protection ledger excluded.'}
(dest/'freeze-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
actions=[json.loads(s) for s in (root/'actions.jsonl').read_text(encoding='utf8').splitlines() if s.strip()]
chron='\n'.join(f"- {a.get('utc','')} — {a.get('action',a.get('text',a.get('label','')))}" for a in actions)
note=f'''# Postfix Windows PA available acquisition complete — 8/8

Source35528dea, resulting-main CI38384969271 attempt2 3/3 SUCCESS, standalone EXEcc36f832. [Full continuous dual-monitor segment2 parts, SHA/reassembly and complete raw-file manifest](evidence/pa-postfix-35528dea/segment2/freeze-manifest.json). [All screenshots, fresh UIA/HWND/native actions, entire cross-restart Narro-M7-Logs folder, helper snapshots and owned database](evidence/pa-postfix-35528dea/segment2/observations-all-Narro-M7-Logs-owned-db.zip). Segment1 remains immutable and published separately.

PA05 named LG125→100→125, same-monitor100% normal presentation pairs and edge drag, real logical display removal, explicit Automatic fallback, duplicate→extend recovery; verified original primary/DPI restored. Physical HDMI unplug NOT RUN. PA06 volume0/100 intent markers, real shortest-supported5min break with automatic return to work; Focus assist ON and actual audio/toast verdict reserved for aggregate analysis. PA07 qualifying138x64px drag, normal tray Quit, same exact EXE relaunch, Timer restored paused at138,269; independent native C5 saved-position PASS preserved before later cleanup runs. Fresh time ledger remains for review. PA08 earlier ec7673c installed build → new35528dea same-version maintenance reinstall in owned directory, actual installed EXE auto launch and retained4tasks/10sessions. MSI NOT RUN (tool policy); schema crossing and autostart not exercised. Quiet paused floating-only3x60s measurement is separately recorded without OBS.

**Counters:** available acquisition8/8, aggregate review0/8, three corrective families0/3 fully accepted pending review. No Narro source/test/runtime/config edits during acquisition. Mandatory3/10 unchanged, M10 blocked, M11 dormant. Observations include nested Add opener focus, Focus Add footer and shortcut behavior; none are silently promoted to final source-parity PASS. Original-profile restoration proof, when present in bundle, establishes identical original database hash.

**Next:** aggregate both recordings/screens/logs, disposition PA01–08 and sufficiently exercised open M1–M9 gates; correct only confirmed residuals with regressions/PR/CI/main/native verification. Do not repeat the whole available matrix. Preserve approved picker/upload/218icons and independent source-owner work.

Chronological manifest:

{chron}
'''
(repo/'work-log/2026-10-13-pa-postfix-acquisition-complete.md').write_text(note,encoding='utf8')
line='**CURRENT postfix acquisition COMPLETE8/8:** [Full segment2 evidence and continuation](work-log/2026-10-13-pa-postfix-acquisition-complete.md). Both dual-screen recordings, screenshots/UIA/HWND, entire Narro-M7-Logs and owned DB published. Aggregate review0/8; corrected overall0/3; independent C5 placement PASS. Source35528dea/EXEcc36f832. NEXT aggregate review, then confirmed residual fixes only; MSI/physical unplug NOT RUN, no M10 advancement.\n\n'
for name in ('HANDOFF.md','TODO.md','STATUS.md'):
 p=repo/name;s=p.read_text(encoding='utf8');pos=s.index('\n')+1;p.write_text(s[:pos]+'\n'+line+s[pos:],encoding='utf8')
print(json.dumps({'parts':len(parts),'video_sha256':whole.hexdigest(),'raw_entries':len(entries),'raw_bytes':raw.stat().st_size,'actions':len(actions)}))

