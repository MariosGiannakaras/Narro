from pathlib import Path
import subprocess,json,datetime
r=Path(r'C:\Users\MariosG\.codex\worktrees\m7-native-paint\NarroUpload')
latest=json.loads(subprocess.check_output(['gh','api','repos/MariosGiannakaras/Narro/actions/runs/38384969271'],encoding='utf-8'))
older=json.loads(subprocess.check_output(['gh','api','repos/MariosGiannakaras/Narro/actions/runs/38380701881'],encoding='utf-8'))
assert latest['head_sha']=='35528dea615e28b146d5eb808cc9432582184738' and latest['run_attempt']==2
assert subprocess.run(['git','merge-base','--is-ancestor','123ecfa18cac89432f337fba45a8bf84fa088564',latest['head_sha']],cwd=r).returncode==0
note=f'''# Final published capacity checkpoint — PA native continuation

UTC{datetime.datetime.now(datetime.timezone.utc).isoformat()}. User requested publication before a usage stop. Current account5h remaining was4%; no new profile isolation or substantial physical recording started with that remaining capacity. This checkpoint does not mark the task complete.

Exact resulting-main CI38384969271 attempt2 source35528dea615e28b146d5eb808cc9432582184738 **{latest['status'].upper()}**, conclusion{latest['conclusion'] or 'PENDING'}. PR349 code merged and exact PR CI3/3 already verified; corrected physical0/3. Initial acquisition8/8 and analysis8/8 remain frozen. Original profiles restored/hash-identical; no corrected launch or new capture. Supplemental CI logs, verification data, prepared action order and guarded helper snapshots are uploaded in the two prior checkpoint ZIPs. Unrelated generated icon directories remain local and excluded; private originals/backups/ledger are deliberately not evidence uploads.

Older PR348 resulting-main CI38380701881 attempt2 is now **{older['status'].upper()}/{older['conclusion'] or 'PENDING'}**. Repository CI uses shared windows-ci-refs/heads/main concurrency and cancel-in-progress. Avoid rerunning older main jobs while this latest combined-source job is active: source123ecfa1 is a verified ancestor of35528dea, which includes both PR348 and PR349. This updates CI continuation only; it does not take over the other source owner's implementation or claim their final native/source parity acceptance. No unsupported cancellation attribution.

ONE NEXT: finish latest CI38384969271 attempt2, verify matching resulting-main production/visual/Focus artifacts and executable hash, then run E:\\SystemFiles\\Desktop\\Narro-PA-postfix-20261013\\CAPTURE_ORDER.md in owned profiles with continuous dual-screen OBS. Refresh current M1–M9 open evidence matrix first. Only then aggregate-review the full new recording and close actually proven gates. Final restored original-profile/topology/motion proof and full evidence publication required. MSI policy-blocked and physical HDMI unplug remain unmet paths; no product-policy bypass. Mandatory3/10, M10 entry blocked, no M11/live Blitzit.
'''
(r/'work-log/2026-10-13-pa-native-final-capacity-handoff.md').write_text(note,encoding='utf-8')
line='**Capacity checkpoint uploaded:** [Latest combined-main CI and exact physical continuation](work-log/2026-10-13-pa-native-final-capacity-handoff.md). Do not rerun older-main CI against the shared concurrency group. Corrected physical0/3; original profiles restored, no new capture.\n\n'
for name in ('HANDOFF.md','STATUS.md','TODO.md'):
 f=r/name;s=f.read_text(encoding='utf-8');pos=s.index('\n')+1;s=s[:pos]+'\n'+line+s[pos:]
 if name=='HANDOFF.md':
  lines=s.splitlines();lines=[('**One exact next ChatGPT CI action:** older PR348 resulting-main CI38380701881 attempt2 CANCELLED. Preserve source ownership; use the latest combined-main CI38384969271 attempt2 for35528dea (verified descendant of PR348 merge123ecfa1). Do not rerun older main while the shared CI group is active. On success verify current artifacts and preserve PA01–08 physical ownership. No physical PASS inferred. [Current combined CI handoff](work-log/2026-10-13-pa-native-final-capacity-handoff.md).' if x.startswith('**One exact next ChatGPT action:**') else x) for x in lines];s='\n'.join(lines)+'\n'
 f.write_text(s,encoding='utf-8')
print(json.dumps({'latest':latest['status'],'older':older['conclusion']}))
