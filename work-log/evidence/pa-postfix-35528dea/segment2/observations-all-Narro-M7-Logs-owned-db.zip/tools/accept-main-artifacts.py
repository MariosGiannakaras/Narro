from pathlib import Path,PurePosixPath
import hashlib,json,zipfile,shutil,subprocess,datetime
from PIL import Image,ImageStat
root=Path(__file__).resolve().parent.parent;repo=Path(r'C:\Users\MariosG\.codex\worktrees\m7-native-paint\NarroUpload')
source='35528dea615e28b146d5eb808cc9432582184738'
run=json.loads(subprocess.check_output(['gh','api','repos/MariosGiannakaras/Narro/actions/runs/38384969271'],encoding='utf-8'));assert run['head_sha']==source and run['run_attempt']==2 and run['conclusion']=='success'
results=[]
for name,digest,aid in [('focus-runtime','91b0f7a537147371213088377972d3c48691f9be7d7c34560c9a0179a9aee24e',11807982033),('validation','c7e48e7c86a052c1d28d3efcf827241cc9e38e0a179512ed9037d27c7c519dde',11808157722)]:
 file=root/f'analysis/main-attempt2-{name}.zip';assert hashlib.sha256(file.read_bytes()).hexdigest()==digest
 target=file.with_suffix('')
 with zipfile.ZipFile(file) as z:
  assert z.testzip() is None
  for e in z.infolist():
   p=PurePosixPath(e.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in e.filename and ':' not in e.filename
  if target.exists():
   for e in z.infolist():
    if not e.is_dir():assert (target/e.filename).read_bytes()==z.read(e.filename)
  else:z.extractall(target)
  count=len(z.infolist())
 item={'kind':name,'artifact':aid,'sha256':digest,'crc_entries':count}
 if name=='focus-runtime':
  images=list(target.rglob('*.png'));assert images
  for p in images:
   with Image.open(p) as im:im.load();assert max(ImageStat.Stat(im.convert('RGB')).var)>0,p
  item['nonuniform_png']=len(images)
 else:
  exe=target/'narro-m7-validation.exe';sha=hashlib.sha256(exe.read_bytes()).hexdigest();assert sha=='cc36f832b7db7a5c09a1d87cc1b581b32af7680bdff079093db36db1a41856f8'
  item['exe_sha256']=sha
  ready=root/'package/narro-m7-validation.exe'
  if ready.exists():assert hashlib.sha256(ready.read_bytes()).hexdigest()==sha
  else:shutil.copyfile(exe,ready)
 results.append(item)
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'ci':38384969271,'attempt':2,'conclusion':'3/3 SUCCESS','supplemental_artifacts':results,'production':json.loads((root/'analysis/main-attempt2-production.verification.json').read_text()),'visual':json.loads((root/'analysis/main-attempt2-visual.verification.json').read_text()),'physical_acceptance':'0/3; no corrected executable launched','runtime':str(root/'package/narro-m7-validation.exe')}
(root/'analysis/main-accepted-artifacts.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
dest=repo/'work-log/evidence/pa01-08-20261013/corrections';dest.mkdir(parents=True,exist_ok=True);bundle=dest/'main-accepted-artifacts-35528dea.zip';assert not bundle.exists()
with zipfile.ZipFile(bundle,'x',zipfile.ZIP_DEFLATED) as z:
 for name in ('main-attempt2-production.zip','main-attempt2-visual.zip','main-attempt2-focus-runtime.zip','main-attempt2-validation.zip','main-attempt2-production.verification.json','main-attempt2-visual.verification.json','main-accepted-artifacts.json'):z.write(root/'analysis'/name,name)
shutil.copyfile(root/'analysis/main-accepted-artifacts.json',dest/'main-accepted-artifacts-35528dea.json')
note=f'''# Exact resulting-main accepted; physical capture ready

PR349 merged source{source}, [CI38384969271 attempt2](https://github.com/MariosGiannakaras/Narro/actions/runs/38384969271) validation/fast/windows **3/3 SUCCESS**. Initial cancelled attempt remains historical. Current main source/build/test semantics unchanged since35528dea; later main commits docs/evidence only, verified via Git diff. Separate PR348 owner automated acceptance is preserved; no repetition of completed source work.

[All artifact originals and verification JSON](evidence/pa01-08-20261013/corrections/main-accepted-artifacts-35528dea.zip) SHA256{hashlib.sha256(bundle.read_bytes()).hexdigest()}; [compact identity manifest](evidence/pa01-08-20261013/corrections/main-accepted-artifacts-35528dea.json). All downloaded ZIP digests independently match GitHub provider values. Production artifact11808147828 CRC3/3, EXE/NSIS PE and MSI CFB valid, standalone x64. Visual11808301580 CRC341/341, PNG168/168 decode/nonuniform, both-theme Add focus/long-title/summary-row assertions present. Packaged Focus11807982033 CRC{results[0]['crc_entries']}, PNG{results[0]['nonuniform_png']} decode/nonuniform. Validation11808157722 CRC{results[1]['crc_entries']}; exact EXE SHA256cc36f832b7db7a5c09a1d87cc1b581b32af7680bdff079093db36db1a41856f8 is byte-identical to production standalone.

Ready exact runtime E:\\SystemFiles\\Desktop\\Narro-PA-postfix-20261013\\package\\narro-m7-validation.exe. NSIS SHAff5e212a0f0843e707ddf3d231e0fd3d8f97da4d0196e4dac0c82dfbae19c5aa; MSI SHA5e369362c4cd5ef35923073f1573f8837dbae8fe47b7e195cb02202e63a8b21f. No corrected runtime launched yet; original profiles restored. Artifact/CI acceptance is not physical acceptance.

User restored usage budget and authorized normal continuation. Workflow: preflight source/artifact/environment/profile safety and open M1–M9 evidence matrix; continuous dual-screen owned-profile capture with compatible checks batched and timestamp bookmarks; freeze useful segment; aggregate review; only confirmed corrections with regressions/PR/CI/guarded merge. Quiet3-run floating CPU/memory protocol separate. Do not analyze/code during useful capture. Same recording may disposition only sufficiently exercised gates. Corrected physical0/3, baseline acquisition8/8/review8/8, mandatory3/10; M10 blocked, no optional M11/live Blitzit.

ONE NEXT: isolate protected original profiles using prepared safety ledger, start verified-loopback4480x1080 OBS, launch this exact EXE and execute CAPTURE_ORDER.md. Refresh actual HWND/UIA rather than old hardcoded probes. MSI product-policy barrier not bypassed; physical HDMI disconnect cannot be simulated.
'''
(repo/'work-log/2026-10-13-pa-resulting-main-accepted-capture-ready.md').write_text(note,encoding='utf-8')
line='**CURRENT PA capture ready:** resulting-main CI38384969271 attempt2 **3/3 SUCCESS**, exact EXE SHA256cc36f832b7db7a5c09a1d87cc1b581b32af7680bdff079093db36db1a41856f8. [Uploaded original artifacts, hashes and dense physical workflow](work-log/2026-10-13-pa-resulting-main-accepted-capture-ready.md). Budget restored/user resumed. NEXT owned-profile isolation and continuous dual-screen capture. Corrected physical0/3; no corrected launch yet. Earlier pending-CI/capacity blocks below are historical.\n\n'
for name in ('HANDOFF.md','TODO.md','STATUS.md','docs/CURRENT_WINDOWS_RESIDUAL_PHYSICAL_SESSION.md','docs/AUDIT_IMPLEMENTATION_CROSSWALK.md'):
 p=repo/name;s=p.read_text(encoding='utf-8');pos=s.index('\n')+1;entry=line.replace('work-log/','../work-log/') if name.startswith('docs/') else line;p.write_text(s[:pos]+'\n'+entry+s[pos:],encoding='utf-8')
print(json.dumps({'production_exe':results[1]['exe_sha256'],'focus_runtime':results[0],'bundle_bytes':bundle.stat().st_size}))
