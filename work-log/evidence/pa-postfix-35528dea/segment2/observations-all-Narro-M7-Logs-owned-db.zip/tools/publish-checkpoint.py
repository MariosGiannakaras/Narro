from pathlib import Path
import hashlib,json,zipfile,datetime
repo=Path(r'C:\Users\MariosG\.codex\worktrees\m7-native-paint\NarroUpload')
old=Path(r'E:\SystemFiles\Desktop\Narro-PA-session-20261013\analysis')
new=Path(r'E:\SystemFiles\Desktop\Narro-PA-postfix-20261013')
dest=repo/'work-log/evidence/pa01-08-20261013/corrections'
dest.mkdir(parents=True,exist_ok=True)
bundle=dest/'pr349-final-ci-and-capture-preparation.zip'
assert not bundle.exists(), 'immutable bundle already exists'
inputs=[old/'ci-38381266484-windows.log',old/'ci-d32a500e-visual-verification.json',old/'ci-d32a500e-visual.zip',new/'CAPTURE_ORDER.md']+sorted(new.glob('*.py'))
entries=[]
with zipfile.ZipFile(bundle,'x',zipfile.ZIP_DEFLATED) as z:
 for p in inputs:
  data=p.read_bytes(); member=('ci/' if p.parent==old else 'preparation/')+p.name
  z.writestr(member,data); entries.append({'path':member,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'d32a500e2f00aeeb2bf73033195e96ee6e46ce10','merged_source':'35528dea615e28b146d5eb808cc9432582184738','pr_ci':38381266484,'resulting_main_ci':38384969271,'resulting_main_status':'validation/fast SUCCESS; Windows IN_PROGRESS at checkpoint','corrected_physical_acceptance':'0/3; no corrected executable launched; original profiles restored','preparation_status':'helpers compiled; profile isolation and restoration NOT EXECUTED; no new capture started','bundle':bundle.name,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'entries':entries}
(dest/'pr349-final-checkpoint-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
note='''# PR349 final CI evidence uploaded; physical continuation prepared

This checkpoint publishes the final green Windows job115243997652 log, original CI visual ZIP11804537470 and verification JSON, plus the prepared post-fix capture order and helper snapshots. [Manifest](evidence/pa01-08-20261013/corrections/pr349-final-checkpoint-manifest.json) lists original-byte hashes; [complete supplemental ZIP](evidence/pa01-08-20261013/corrections/pr349-final-ci-and-capture-preparation.zip). These are evidence snapshots, not repository-consumed tooling. No real-user profile/backup, private protection ledger or credentials are included.

PR349 final head d32a500e2f00aeeb2bf73033195e96ee6e46ce10: exact CI38381266484 validation/fast/windows3/3 SUCCESS;413 library tests and additional target suites PASS. Guarded merge35528dea615e28b146d5eb808cc9432582184738 preserves25/25 changed Git blobs. Resulting-main CI38384969271 currently validation/fast SUCCESS, Windows IN_PROGRESS. No accepted resulting-main EXE yet.

Acquisition8/8, aggregate triage8/8; baseline1/8 PASS,3/8 FAIL,4/8 UNCERTAIN. Corrected physical acceptance0/3. Original profiles remain restored and hash-identical; no corrected Narro launch, no new isolation or post-fix recording. The prepared helpers are not a performed test. OBS both-screen loopback health evidence and actual Display Settings recovery are already published separately. Actual DPI125→100 and Narro alert audio still need exercise. MSI product-policy block and physical HDMI unplug remain distinct unmet paths. Mandatory3/10, M10 blocked; M11/live Blitzit excluded.

ONE NEXT: finish exact resulting-main CI38384969271; verify the matching production/visual artifact provider digests, CRC and EXE hashes; then use E:\\SystemFiles\\Desktop\\Narro-PA-postfix-20261013\\CAPTURE_ORDER.md for owned-profile dense physical capture. Never launch against the original namespace. Prepare a fresh-HWND PA04 lock helper rather than the old hardcoded helper. Freeze and upload the complete new corpus, analyze together, restore original profiles/topology/motion, and disposition only actually exercised M1–M9 requirements. Do not repeat completed PR349 or the immutable baseline capture. No source/test/config changes in this publication.
'''
(repo/'work-log/2026-10-13-pa349-final-evidence-uploaded.md').write_text(note,encoding='utf-8')
line='**Latest uploaded checkpoint:** [Final PR349 CI evidence and prepared physical continuation](work-log/2026-10-13-pa349-final-evidence-uploaded.md). Final Windows log/CI visual ZIP/hash verification and capture-order/helper snapshots are now versioned. Resulting-main CI38384969271: validation/fast SUCCESS, Windows IN_PROGRESS; corrected physical0/3. No corrected launch/isolation/capture yet; original profiles remain restored.\n\n'
for name in ('HANDOFF.md','TODO.md','STATUS.md'):
 p=repo/name; s=p.read_text(encoding='utf-8'); pos=s.index('\n')+1; p.write_text(s[:pos]+'\n'+line+s[pos:],encoding='utf-8')
print(json.dumps({'bundle_bytes':bundle.stat().st_size,'sha256':manifest['bundle_sha256'],'entries':len(entries)}))
