"""Offline digest/CRC/format checks. Does not launch or claim native acceptance."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,zipfile,struct
from PIL import Image,ImageStat
p=argparse.ArgumentParser();p.add_argument('zip');p.add_argument('digest');p.add_argument('source');p.add_argument('artifact',type=int);p.add_argument('kind',choices=['production','visual']);args=p.parse_args()
file=Path(args.zip);actual=hashlib.sha256(file.read_bytes()).hexdigest()
assert actual==args.digest.removeprefix('sha256:'), 'Provider digest mismatch'
target=file.with_suffix('');assert not target.exists(), 'Preserve an existing extraction'
with zipfile.ZipFile(file) as z:
 assert z.testzip() is None, 'CRC failed'
 members=[e for e in z.infolist() if not e.is_dir()]
 for e in members:
  path=PurePosixPath(e.filename)
  assert not path.is_absolute() and '..' not in path.parts and '\\' not in e.filename and ':' not in e.filename, 'Unsafe archive member'
 z.extractall(target)
result={'source':args.source,'artifact':args.artifact,'kind':args.kind,'zip_sha256':actual,'crc_entries':len(members),'files':[],'native_acceptance':'NOT RUN'}
if args.kind=='production':
 assert len(members)==3, 'Expected standalone, NSIS and MSI only'
 for e in members:
  data=(target/e.filename).read_bytes()
  if e.filename.endswith('.exe'):
   assert data[:2]==b'MZ' and len(data)>64
   offset=struct.unpack_from('<I',data,0x3c)[0];assert data[offset:offset+4]==b'PE\0\0'
   machine=struct.unpack_from('<H',data,offset+4)[0]
   if e.filename=='narro.exe':assert machine==0x8664,'Standalone must be x64'
  elif e.filename.endswith('.msi'):assert data[:8]==bytes.fromhex('d0cf11e0a1b11ae1')
  else:raise AssertionError('Unexpected package member')
  result['files'].append({'path':e.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 assert sum(v['path']=='narro.exe' for v in result['files'])==1
 assert sum('/nsis/' in v['path'] for v in result['files'])==1
 assert sum('/msi/' in v['path'] for v in result['files'])==1
else:
 images=list(target.rglob('*.png'));uniform=[]
 for image in images:
  with Image.open(image) as im:
   im.load()
   if max(ImageStat.Stat(im.convert('RGB')).var)==0:uniform.append(str(image.relative_to(target)))
 assert len(images)>0 and not uniform
 reports=list(target.rglob('reports-sessions-add-keyboard-*.html'));summaries=list(target.rglob('reports-sessions-populated-*.html'))
 assert len(reports)==2 and len(summaries)==2
 for report in reports:
  text=report.read_text(encoding='utf-8')
  assert 'data-reports-add-commit-focus-restored="true"' in text and 'data-reports-add-long-title-contained="true"' in text
 for summary in summaries:assert 'data-reports-summary-single-row="true"' in summary.read_text(encoding='utf-8')
 result.update(decoded_png=len(images),uniform_png=uniform,add_focus_overflow_themes=len(reports),summary_row_themes=len(summaries))
out=file.with_suffix('.verification.json');assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result))
