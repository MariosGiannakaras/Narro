import ctypes as c, ctypes.wintypes as w, time, json, pathlib, datetime, sys
root=pathlib.Path(__file__).resolve().parent.parent
pid=int(sys.argv[1]); k=c.windll.kernel32; p=c.windll.psapi
class PE(c.Structure):
    _fields_=[('size',w.DWORD),('usage',w.DWORD),('pid',w.DWORD),('heap',c.c_size_t),('module',w.DWORD),('threads',w.DWORD),('parent',w.DWORD),('priority',w.LONG),('flags',w.DWORD),('exe',w.WCHAR*260)]
class PMC(c.Structure):
    _fields_=[('cb',w.DWORD),('faults',w.DWORD),('peakws',c.c_size_t),('ws',c.c_size_t),('peakpaged',c.c_size_t),('paged',c.c_size_t),('peaknonpaged',c.c_size_t),('nonpaged',c.c_size_t),('pagefile',c.c_size_t),('peakpagefile',c.c_size_t),('private',c.c_size_t)]
k.CreateToolhelp32Snapshot.restype=w.HANDLE;k.OpenProcess.restype=w.HANDLE
k.GetProcessTimes.argtypes=[w.HANDLE,c.POINTER(w.FILETIME),c.POINTER(w.FILETIME),c.POINTER(w.FILETIME),c.POINTER(w.FILETIME)]
p.GetProcessMemoryInfo.argtypes=[w.HANDLE,c.POINTER(PMC),w.DWORD]
k.CloseHandle.argtypes=[w.HANDLE]
def sample():
    h=k.CreateToolhelp32Snapshot(2,0); pe=PE();pe.size=c.sizeof(pe); rows=[]
    ok=k.Process32FirstW(w.HANDLE(h),c.byref(pe))
    while ok:
        rows.append((pe.pid,pe.parent,pe.exe));ok=k.Process32NextW(w.HANDLE(h),c.byref(pe))
    k.CloseHandle(h); ids={pid}
    for _ in range(12):
        more={a for a,b,_ in rows if b in ids}
        if more<=ids:break
        ids|=more
    out=[]
    for a,b,name in rows:
        if a not in ids:continue
        handle=k.OpenProcess(0x410,False,a)
        if not handle:continue
        created,exit_,kernel,user=[w.FILETIME() for _ in range(4)];mem=PMC();mem.cb=c.sizeof(mem)
        if k.GetProcessTimes(handle,c.byref(created),c.byref(exit_),c.byref(kernel),c.byref(user)) and p.GetProcessMemoryInfo(handle,c.byref(mem),c.sizeof(mem)):
            ticks=lambda t:(t.dwHighDateTime<<32)+t.dwLowDateTime
            out.append({'pid':a,'parent':b,'name':name,'cpu_seconds':(ticks(kernel)+ticks(user))/1e7,'working_set':mem.ws,'private_bytes':mem.private})
        k.CloseHandle(handle)
    assert any(x['pid']==pid for x in out),'Narro process disappeared'
    return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonic':time.monotonic(),'processes':out}
allruns=[]
for run in range(3):
    samples=[sample()];start=time.monotonic()
    for sec in range(1,61):
        time.sleep(max(0,start+sec-time.monotonic()));samples.append(sample())
    first={x['pid']:x['cpu_seconds'] for x in samples[0]['processes']}
    last={x['pid']:x['cpu_seconds'] for x in samples[-1]['processes']}
    elapsed=samples[-1]['monotonic']-samples[0]['monotonic'];cpu=sum(last[a]-first[a] for a in first.keys()&last.keys())
    record={'run':run+1,'elapsed_seconds':elapsed,'cpu_seconds':cpu,'cpu_percent_one_core':100*cpu/elapsed,'working_set_mib_final':sum(x['working_set'] for x in samples[-1]['processes'])/1048576,'private_mib_final':sum(x['private_bytes'] for x in samples[-1]['processes'])/1048576,'process_set_stable':first.keys()==last.keys(),'samples':samples}
    allruns.append(record);print(json.dumps({k:v for k,v in record.items() if k!='samples'}),flush=True)
    (root/'observations/quiet-performance-3x60s.json').write_text(json.dumps({'conditions':'Paused compact Timer, Main closed, OBS not recording; other desktop applications remain running. Process-tree CPU percent is per one logical core; no milestone PASS inferred.','pid':pid,'runs':allruns},indent=2),encoding='utf8')
