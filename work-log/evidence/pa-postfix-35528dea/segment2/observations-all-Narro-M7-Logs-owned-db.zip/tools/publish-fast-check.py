from pathlib import Path
import json,shutil,zipfile,hashlib
repo=Path(r'C:\Users\MariosG\.codex\worktrees\m7-native-paint\NarroUpload');root=Path(__file__).resolve().parent.parent
dest=repo/'work-log/evidence/pa01-08-20261013/corrections';dest.mkdir(parents=True,exist_ok=True)
for name in ('main-attempt2-fast-dist.zip','main-attempt2-fast-dist-verification.json'):
 assert not (dest/name).exists();shutil.copyfile(root/'analysis'/name,dest/name)
snapshot=dest/'main-attempt2-fast-artifact-verifier.zip'
with zipfile.ZipFile(snapshot,'x',zipfile.ZIP_DEFLATED) as z:z.write(root/'tools/check-fast-artifact.py','check-fast-artifact.py')
note=f'''# Additional bounded artifact integrity check — resulting-main attempt2

Exact resulting-main source35528dea615e28b146d5eb808cc9432582184738, CI38384969271 attempt2. Validation/fast SUCCESS; Windows still running at checkout, production artifact not yet available. No second Narro launch, profile isolation or recording.

Downloaded original frontend ZIP artifact11807392751; independently computed SHA25624705173b669e691ebeeed77a17eed159a32d0f4f15487baf756a7fa37cc6dab matches GitHub provider digest. **86/86 files CRC PASS;16/16 configured HTML entries present;432/432 local HTML asset references resolve to archive members**. Safe relative ZIP members checked, all member bytes/SHA hashes recorded. This is compiled frontend integrity, not runtime behavior or physical Windows acceptance. JS dynamic imports/visual parity are outside this bounded check.

[Original artifact ZIP](evidence/pa01-08-20261013/corrections/main-attempt2-fast-dist.zip), [verification result and per-file hashes](evidence/pa01-08-20261013/corrections/main-attempt2-fast-dist-verification.json), [verifier snapshot](evidence/pa01-08-20261013/corrections/main-attempt2-fast-artifact-verifier.zip) SHA256{hashlib.sha256(snapshot.read_bytes()).hexdigest()}. Verifier is an evidence snapshot, not repository-consumed tooling. No source/runtime/test/build/config change or new CI trigger.

Physical counters unchanged: original acquisition8/8, analysis8/8; corrected0/3. Original profiles remain restored. ONE NEXT remains exact Windows attempt2 completion/package verification, then the prepared owned-profile continuous dual-screen capture. Do not restart older-main CI in the same concurrency group. No M10/M11 advancement.
'''
(repo/'work-log/2026-10-13-pa-main-fast-artifact-integrity.md').write_text(note,encoding='utf-8')
line='**Additional completed check:** [Resulting-main attempt2 frontend artifact integrity](work-log/2026-10-13-pa-main-fast-artifact-integrity.md):86/86 CRC files,16/16 HTML entries,432/432 local asset references, provider SHA match. Evidence uploaded; Windows CI still pending, corrected physical0/3.\n\n'
for name in ('HANDOFF.md','TODO.md','STATUS.md'):
 p=repo/name;s=p.read_text(encoding='utf-8');pos=s.index('\n')+1;p.write_text(s[:pos]+'\n'+line+s[pos:],encoding='utf-8')
print('Frontend integrity evidence prepared for main publication')
