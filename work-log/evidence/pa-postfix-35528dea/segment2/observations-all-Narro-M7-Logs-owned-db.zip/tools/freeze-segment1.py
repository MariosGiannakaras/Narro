from pathlib import Path
import json,hashlib,zipfile,sqlite3,subprocess,shutil,datetime
root=Path(__file__).resolve().parent.parent;repo=Path(r'C:\Users\MariosG\.codex\worktrees\m7-native-paint\NarroUpload')
db=Path.home()/'AppData/Roaming/com.mariosg.Narro/narro.db'
assert json.loads((db.parent/'pa-owned-profile.json').read_text())['sessionRoot']==str(root)
assert json.loads((root/'profile-protection-private.json').read_text())['state']=='OWNED_PROFILE_ACTIVE'
video=Path(r'E:\SystemFiles\Desktop\NarroUpload\artifacts\m7-pr234-native-20261005\video\2026-10-13 15-54-18.mkv')
ffprobe=r'E:\SystemFiles\Desktop\NarroUpload\artifacts\ui-validation-tools\ffmpeg-portable\ffmpeg-9.0.2-essentials_build\bin\ffprobe.exe'
meta=json.loads(subprocess.check_output([ffprobe,'-v','error','-show_entries','format=duration,size:stream=index,codec_name,codec_type,width,height,r_frame_rate,sample_rate,channels','-of','json',str(video)],encoding='utf-8'))
assert any(s.get('width')==4480 and s.get('height')==1080 for s in meta['streams'])
freeze=root/'freeze-segment1';assert not freeze.exists();freeze.mkdir()
source=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True);target=sqlite3.connect(freeze/'owned-profile.db');source.backup(target);assert target.execute('pragma integrity_check').fetchone()[0]=='ok';target.close();source.close()
dest=repo/'work-log/evidence/pa-postfix-35528dea/segment1';dest.mkdir(parents=True,exist_ok=True)
raw=dest/'observations-logs-owned-db.zip';assert not raw.exists()
inputs=list((root/'observations').glob('*'))+list(root.glob('*.py'))+[root/p for p in ('CAPTURE_ORDER.md','actions.jsonl','native-actions.jsonl','key-dispatch.jsonl','motion-original.json','motion-normal.json','motion-reduced.json','motion-repeat-normal.json') if (root/p).exists()]+list((root/'package/Narro-M7-Logs').rglob('*'))+[freeze/'owned-profile.db']
entries=[]
with zipfile.ZipFile(raw,'x',zipfile.ZIP_DEFLATED) as z:
 for file in sorted(inputs):
  if not file.is_file():continue
  member=file.relative_to(root).as_posix();data=file.read_bytes();z.writestr(member,data);entries.append({'path':member,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
parts=[];whole=hashlib.sha256()
with video.open('rb') as f:
 index=1
 while block:=f.read(48*1024*1024):
  name=f'continuous.mkv.part{index:03d}';path=dest/name;assert not path.exists();path.write_bytes(block);whole.update(block);parts.append({'path':name,'bytes':len(block),'sha256':hashlib.sha256(block).hexdigest()});index+=1
record={'freeze_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'35528dea615e28b146d5eb808cc9432582184738','ci':38384969271,'attempt':2,'exe_sha256':'cc36f832b7db7a5c09a1d87cc1b581b32af7680bdff079093db36db1a41856f8','video':{'original_name':video.name,'start_utc':'2026-10-13T12:54:18.359Z','stop_utc':'2026-10-13T13:37:36.891Z','sha256':whole.hexdigest(),'metadata':meta,'parts':parts,'reassembly':'Concatenate parts in numeric order as binary bytes; verify whole SHA256 before decoding.'},'raw_bundle':{'path':raw.name,'sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'entries':entries},'counter':'Postfix acquisition4/8 primary groups; PA05-08 pending; aggregate review NOT STARTED; corrected native0/3','limits':['Part1 contains100% Panel/125% Timer cross-monitor pairs, normal/reduced and expand/collapse; same-monitor100% Timer and exact DPI switch not yet acquired.','Initial failed drag attempts used the live-title interior; previous verified drag protocol uses empty left edge7,36. Do not classify failed input targeting as app drag FAIL.','Initial125% UIA geometry was virtualized; probe corrected to per-monitor awareness, timestamps/bookmarks preserved.','Toolbar cancel/locked success opener focused; nested task-detail cancel focuses Close, success focuses dialog root; retain observation for aggregate analysis.','MSI policy barrier not bypassed; physical HDMI unplug cannot be simulated.'],'profile':'Original profiles PROTECTED; owned test namespace ACTIVE; no original/private backups or protection ledger included. This is a midpoint checkpoint, restoration not yet performed.'}
(dest/'freeze-manifest.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
actions=[json.loads(s) for s in (root/'actions.jsonl').read_text().splitlines() if s.strip()]
chron='\n'.join(f"- {a['utc']} — {a['action']}" for a in actions)
note=f'''# Postfix PA acquisition segment1 frozen —4/8 primary groups

Exact resulting-main35528dea/CI38384969271 attempt2 3/3 SUCCESS; EXE SHA256cc36f832b7db7a5c09a1d87cc1b581b32af7680bdff079093db36db1a41856f8. Continuous OBS2598.517s/296375317B,4480x1080 H26460fps/AAC48k stereo, both monitors side by side. [Full byte-preserving media reassembly and raw-file manifest](evidence/pa-postfix-35528dea/segment1/freeze-manifest.json); [all observed screenshots/UIA/HWND/actions/current entire Narro-M7-Logs and owned DB snapshot](evidence/pa-postfix-35528dea/segment1/observations-logs-owned-db.zip). No actual encoded-audio verdict from stream existence alone.

PA01 normal/reduced3 cross-monitor Panel↔Timer pairs and3 expand/collapse pairs each; PA02 real Board entry; PA03 actual120s EST deadline with existing82s work retained, compact/expanded Time's Up125%, Extend negative overtime and Pause; PA04 toolbar cancellation and actual4s SQLite lock with real Add/Escape/Tab/ShiftTab plus pending read-only UIA, one manual60s insertion, task-detail cancellation and second60s success. Task-detail entry is **Sessions row action menu → Edit**; clicking a time opens its inline editor, clicking Overview Done text does not open details. Do not repeat these navigation experiments.

Observations bookmarked only, aggregate analysis/visual verdicts not performed: Focus create footer clipped at700px requiring Return recovery; in-app Ctrl+Alt+P did not pause in Focus (visible Pause works); toolbar Add opener focused correctly, nested task-detail cancellation focuses Close and success focuses dialog root. Initial title-interior drag attempts did not move; use previously physically verified empty edge7,36 for next real drag, do not conflate wrong hit target with app failure. Windows WGC screenshots timeout/geometry unavailable; actual desktop gdigrab, native UIA and real mouse/keyboard used with fresh target/focus checks. UIA probe corrected to per-monitor awareness before125% hit-target actions; browser time controls require actual numeric keys rather than Unicode type_text. These are evidence-tool adaptations, no Narro source changes.

**Counters:** new acquisition4/8 primary groups, analysis0/8 for new corpus, corrected acceptance0/3. Baseline8/8 acquisition/review and historical1PASS/3FAIL/4UNCERTAIN unchanged. M1–M9 reuse disposition waits for sufficient new evidence and aggregate review; mandatory3/10, no M10 advancement/M11. Originals remain protected; owned namespace active, runtime PID40372 paused; restore originals/motion/topology at campaign end, not before next launch. Private originals/ledger excluded.

**ONE NEXT:** prepare/read actual Display Settings + Narro Preferences navigation, start second continuous OBS segment, PA05 named LG125→100→125 and safe topology recovery, PA06 real sound/toast, PA07 fresh edge drag≥64px/normal tray Quit/same EXE recovery+time ledger, PA08 owned NSIS earlier-build upgrade. Quiet3-run performance separate. No intermediate Narro analysis/fixes until available acquisition completes. Current logs snapshot is partial; final entire cross-restart folder must also be published.

Chronological action manifest:

{chron}
'''
(repo/'work-log/2026-10-13-pa-postfix-segment1-acquisition.md').write_text(note,encoding='utf-8')
line='**CURRENT postfix acquisition checkpoint:** [Segment1 full video/logs/screens/owned DB published](work-log/2026-10-13-pa-postfix-segment1-acquisition.md). New acquisition4/8 primary groups; new analysis0/8; corrected native0/3. Original profiles PROTECTED/owned namespace ACTIVE; source35528dea EXEcc36f832. NEXT PA05–08 dense segment2, then aggregate review. Nested opener focus and other observations bookmarked; no Narro source edits.\n\n'
for name in ('HANDOFF.md','TODO.md','STATUS.md'):
 p=repo/name;s=p.read_text(encoding='utf-8');pos=s.index('\n')+1;p.write_text(s[:pos]+'\n'+line+s[pos:],encoding='utf-8')
print(json.dumps({'video_sha256':whole.hexdigest(),'parts':len(parts),'raw_bundle_bytes':raw.stat().st_size,'raw_entries':len(entries),'actions':len(actions)}))
