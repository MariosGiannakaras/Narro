from pathlib import Path,PurePosixPath
import hashlib,json,zipfile,posixpath
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
root=Path(__file__).resolve().parent.parent;file=root/'analysis/main-attempt2-fast-dist.zip'
digest=hashlib.sha256(file.read_bytes()).hexdigest()
assert digest=='24705173b669e691ebeeed77a17eed159a32d0f4f15487baf756a7fa37cc6dab'
expected={'index.html','focus.html','visual-fixtures.html','focus-panel-fixture.html','focus-editor-fixture.html','floating-timer-fixture.html','task-reorder-fixture.html','task-metric-fixture.html','task-schedule-fixture.html','task-notes-fixture.html','task-subtasks-fixture.html','list-settings-fixture.html','search-palette-fixture.html','archive-fixture.html','theme-settings-fixture.html','reports-fixture.html'}
with zipfile.ZipFile(file) as z:
 assert z.testzip() is None
 names={e.filename for e in z.infolist() if not e.is_dir()}
 for name in names:
  path=PurePosixPath(name);assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
 # Artifact upload flattens dist; all configured entrypoints must be present.
 assert expected<=names,expected-names
 refs=[]
 class Parser(HTMLParser):
  def handle_starttag(self,tag,attrs):
   a=dict(attrs)
   for key in ('src','href'):
    if key not in a:continue
    v=urlsplit(a[key])
    if v.scheme or v.netloc or not v.path:continue
    resolved=posixpath.normpath(unquote(v.path).lstrip('/') if v.path.startswith('/') else posixpath.join(posixpath.dirname(self.member),unquote(v.path)))
    assert resolved in names,(self.member,a[key],resolved)
    refs.append({'html':self.member,'reference':a[key],'member':resolved})
 for name in sorted(expected):
  text=z.read(name).decode('utf-8');assert '<html' in text.lower() and '<script' in text.lower(),name
  parser=Parser();parser.member=name;parser.feed(text)
 hashes=[{'path':name,'bytes':len(z.read(name)),'sha256':hashlib.sha256(z.read(name)).hexdigest()} for name in sorted(names)]
 result={'source':'35528dea615e28b146d5eb808cc9432582184738','ci':38384969271,'attempt':2,'artifact':11807392751,'zip_sha256':digest,'crc_files':len(names),'configured_html_entries':len(expected),'resolved_html_asset_references':len(refs),'files':hashes,'references':refs,'scope':'Compiled frontend artifact integrity only; Windows package/native acceptance NOT RUN'}
(root/'analysis/main-attempt2-fast-dist-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('files','references')}))
