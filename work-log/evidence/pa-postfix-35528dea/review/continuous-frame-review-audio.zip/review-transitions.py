from pathlib import Path
from PIL import Image,ImageDraw
import json,datetime,subprocess,hashlib
r=Path(__file__).resolve().parent.parent;o=r/'analysis/postfix-review';o.mkdir(exist_ok=True)
ff=r'E:\SystemFiles\Desktop\NarroUpload\artifacts\ui-validation-tools\ffmpeg-portable\ffmpeg-9.0.2-essentials_build\bin\ffmpeg.exe'
videos=[Path(r'E:\SystemFiles\Desktop\NarroUpload\artifacts\m7-pr234-native-20261005\video\2026-10-13 15-54-18.mkv'),Path(r'E:\SystemFiles\Desktop\NarroUpload\artifacts\m7-pr234-native-20261005\video\2026-10-13 17-04-20.mkv')]
dt=lambda s:datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
starts=[dt('2026-10-13T12:54:18.359Z'),dt('2026-10-13T14:04:19.938Z')]
groups=[('normal-expand',0,'2026-10-13T13:01:15','2026-10-13T13:02:05',1920),('reduced-expand',0,'2026-10-13T13:02:53','2026-10-13T13:03:02',1920),('normal-LG100-expand',1,'2026-10-13T14:18:39','2026-10-13T14:18:49',0),('normal-cross',0,'2026-10-13T12:59:44','2026-10-13T13:00:00',1920),('reduced-cross',0,'2026-10-13T13:02:42','2026-10-13T13:02:53',1920),('normal-same-LG100',1,'2026-10-13T14:18:28','2026-10-13T14:18:39',0)]
events=[json.loads(s) for s in (r/'package/Narro-M7-Logs/session-20261013-125438.388Z-40372/events.jsonl').read_text().splitlines()]
manifest=[]
for group,vi,lo,hi,px in groups:
 seq=[a for a in events if a['event']=='focus-presentation' and lo<a['timestampUtc']<hi]
 # Drop intermediate outgoing-panel reports immediately followed by final Timer commit.
 seq=[a for i,a in enumerate(seq) if not(a['details']['presentation']=='panel' and i+1<len(seq) and seq[i+1]['details']['presentation']=='timerCompact' and (dt(seq[i+1]['timestampUtc'])-dt(a['timestampUtc'])).total_seconds()<.7)]
 for n,a in enumerate(seq,1):
  label=f'{group}-{n}-{a["details"]["presentation"]}';offset=(dt(a['timestampUtc'])-starts[vi]).total_seconds()-.85
  vf=f'[0:v]split=2[p][t];[p]crop=425:875:{px}:0,scale=110:226[p1];[t]crop=425:875:911:205,scale=110:226[t1];[p1][t1]hstack=inputs=2'
  data=subprocess.check_output([ff,'-hide_banner','-loglevel','error','-ss',str(offset),'-i',str(videos[vi]),'-t','1.4','-filter_complex',vf,'-f','rawvideo','-pix_fmt','rgb24','pipe:1'])
  framebytes=220*226*3;count=len(data)//framebytes;assert count>=80,(label,count)
  sheet=Image.new('RGB',(14*220,((count+13)//14)*246),(35,35,35));d=ImageDraw.Draw(sheet)
  for k in range(count):
   im=Image.frombytes('RGB',(220,226),data[k*framebytes:(k+1)*framebytes]);x=(k%14)*220;y=(k//14)*246;sheet.paste(im,(x,y));d.text((x+2,y+226),f'{offset+k/60:.3f}s #{k}',fill='white')
  p=o/(label+'.jpg');sheet.save(p,quality=93)
  manifest.append({'label':label,'event_utc':a['timestampUtc'],'video':str(videos[vi]),'offset_seconds':offset,'duration_seconds':1.4,'frames':count,'all_decoded_frames_in_sheet':True,'sheet':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'roi_note':'Left panel target, right Timer target including background; scaled overview, original recording authoritative for fine pixels.'})
(o/'transition-review-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8');print(json.dumps({'sheets':len(manifest),'frames':sum(x['frames'] for x in manifest)}))

