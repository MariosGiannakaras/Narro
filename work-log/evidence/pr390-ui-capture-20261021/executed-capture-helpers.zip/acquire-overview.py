import importlib.util,re
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=100
c.cli('--raw','eval','async()=>{await window.__TAURI_INTERNALS__.invoke("main_window_show");await window.__TAURI_INTERNALS__.invoke("main_window_focus");return {url:location.href};}')
def run():
 s=c.cli('snapshot');m=re.findall(r'button "[^"\n]*\d{4}[^"\n]*\d{4}"[^\r\n]*\[ref=(e\d+)\]',s)
 if len(m)!=1:raise RuntimeError('Expected one actual Reports range button')
 c.journal('Open actual Overview calendar',ref=m[0]);c.cli('click',m[0]);c.cli('snapshot')
 for name in ['Previous year','Next year','Previous month','Next month']:c.button(name,keyboard=True)
 c.cli('screenshot','--filename',str(p/'P1-overview-calendar-webview.png'));c.cli('press','Escape');c.cli('snapshot')
c.record('P1-overview-calendar',run);print('P1 acquired without analysis')
