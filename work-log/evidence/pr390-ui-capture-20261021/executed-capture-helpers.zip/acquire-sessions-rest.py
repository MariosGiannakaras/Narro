import importlib.util,re
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=280

def run():
 for name in ['Previous year','Next year','Previous month','Next month']:
  s=c.cli('snapshot');rows=[v for v in s.splitlines() if 'button "'+name+'"' in v and '[disabled]' not in v]
  if len(rows)!=1:raise RuntimeError('Expected one enabled actual Sessions arrow '+name)
  ref=re.search(r'\[ref=(e\d+)\]',rows[0]).group(1);c.journal('Sessions actual enabled pointer navigation',name=name,ref=ref);c.cli('click',ref)
 c.cli('screenshot','--filename',str(p/'P2-sessions-calendar-webview.png'));c.button('Cancel',keyboard=True);c.button('+ Add Session',keyboard=True);c.cli('snapshot');c.cli('screenshot','--filename',str(p/'P2-add-session-webview.png'))
 for _ in range(4):c.cli('press','Tab')
 c.cli('snapshot');c.cli('press','Escape');c.cli('snapshot')
c.record('P2-sessions-navigation-dialog',run);print('P2 acquired incl opening; Save blank/keyboard states, no new Save commit claim')
