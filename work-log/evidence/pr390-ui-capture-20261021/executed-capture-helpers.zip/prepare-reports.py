import importlib.util
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=10
c.cli('tab-select','1');c.button('Reports',keyboard=True);print('\n'.join(x for x in c.cli('snapshot').splitlines() if any(v in x for v in ['button','tab ','combobox'])))
