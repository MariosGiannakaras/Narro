import importlib.util
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=400

def run():
 c.button('Settings',keyboard=True);c.button('View shortcuts',keyboard=True);c.cli('snapshot');c.cli('screenshot','--filename',str(p/'P3-shortcuts-webview.png'));c.journal('Keyboard Tab traversal only; no global shortcut registration toggles or OS hotkeys')
 c.cli('run-code','async(page)=>{for(let i=0;i<12;i++){await page.keyboard.press("Tab");await page.waitForTimeout(450);}}');c.cli('snapshot');c.cli('press','Escape');c.cli('snapshot');c.cli('press','Escape');c.cli('snapshot')
c.record('P3-shortcuts-accessible-ui',run);print('P3 acquired; no screen-reader/native-registration PASS')
