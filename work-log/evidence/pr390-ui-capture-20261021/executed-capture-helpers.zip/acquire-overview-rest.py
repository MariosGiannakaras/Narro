import importlib.util,re,json
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=130

def run():
 for idx in [0,1]:
  for prefix in ['Previous year from ','Next year from ','Previous month from ','Next month from ']:
   s=c.cli('snapshot');m=re.findall(r'button "('+re.escape(prefix)+r'[^"\n]*)"[^\r\n]*\[ref=(e\d+)\]',s)
   if len(m)!=2:raise RuntimeError('Expected two visible calendar controls '+prefix)
   name,ref=m[idx];c.journal('Calendar navigation',name=name,calendar=idx,ref=ref);c.cli('run-code','async(page)=>{const b=page.getByRole("button",{name:'+json.dumps(name)+',exact:true});await b.focus();await b.press("Space");}')
 c.cli('screenshot','--filename',str(p/'P1-overview-calendar-webview.png'));c.cli('press','Escape');c.cli('snapshot')
c.record('P1-overview-calendar-navigation',run);print('P1 acquired, including initial opening clip; no visual verdict')
