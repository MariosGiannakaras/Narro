import importlib.util,re
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=200
s=c.cli('snapshot');m=re.findall(r'tab "Sessions Beta"[^\r\n]*\[ref=(e\d+)\]',s)
if len(m)!=1:raise RuntimeError('Expected Sessions tab')
c.cli('click',m[0]);print('\n'.join(x for x in c.cli('snapshot').splitlines() if any(v in x for v in ['button','textbox','dialog'])))
