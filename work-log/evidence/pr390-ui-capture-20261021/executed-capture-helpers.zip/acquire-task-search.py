import importlib.util,re,time
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=600

def run():
 c.button('All my lists',keyboard=True);s=c.cli('snapshot');a=re.findall(r'- article \[ref=(e\d+)\]',s)
 if not a:raise RuntimeError('Expected actual Board article')
 c.journal('Hover first actual Board article',ref=a[0]);c.cli('hover',a[0]);time.sleep(1);c.cli('snapshot');c.cli('screenshot','--filename',str(p/'P5-task-rail-webview.png'))
 c.cli('run-code','async(page)=>{const a=page.getByRole("article").first();const b=a.getByRole("button").first();await b.focus();for(let i=0;i<5;i++){await page.keyboard.press("Tab");await page.waitForTimeout(450);}}');c.cli('snapshot');c.button('Search',keyboard=True);c.cli('snapshot');c.cli('screenshot','--filename',str(p/'P5-search-back-webview.png'));c.cli('press','Escape');c.cli('snapshot')
c.record('P5-task-actions-search',run);print('P5 acquired; no task identity/completion mutation intended')
