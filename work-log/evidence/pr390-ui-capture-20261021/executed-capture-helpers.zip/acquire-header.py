import importlib.util,re,time
from pathlib import Path
p=Path(__file__).parent;spec=importlib.util.spec_from_file_location('cap',p/'capture-helper.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.serial=500
c.cli('tab-select','0');c.cli('run-code','async(page)=>{await page.emulateMedia({reducedMotion:"no-preference"});}');c.cli('--raw','eval','async()=>{await window.__TAURI_INTERNALS__.invoke("focus_surface_show");return true;}')
def run():
 for name in ['Preferences','Home','Compact view']:
  s=c.cli('snapshot');m=re.findall(r'button "'+re.escape(name)+r'"[^\r\n]*\[ref=(e\d+)\]',s)
  if len(m)!=1:raise RuntimeError('Expected real header control '+name)
  c.journal('Actual header hover',label=name,ref=m[0]);c.cli('hover',m[0]);time.sleep(.8)
 c.cli('run-code','async(page)=>{await page.getByRole("button",{name:"Preferences",exact:true}).focus();for(let i=0;i<3;i++){await page.keyboard.press("Tab");await page.waitForTimeout(450);}}');c.cli('screenshot','--filename',str(p/'P4-focus-header-webview.png'));c.cli('--raw','eval','()=>Array.from(document.querySelectorAll("button")).filter(e=>["Preferences","Home","Compact view"].includes(e.getAttribute("aria-label"))).map(e=>({label:e.getAttribute("aria-label"),rect:e.getBoundingClientRect().toJSON()}))')
c.record('P4-focus-header-hover-keyboard',run);c.button('Home',keyboard=True);c.cli('tab-select','1');print('P4 acquired; no Timer transition replay')
