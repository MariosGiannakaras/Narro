import importlib.util,time
from pathlib import Path
r=Path(__file__).parent
s=importlib.util.spec_from_file_location('assist',r/'capture-helper-assisted.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def wait():
 end=time.monotonic()+310
 while time.monotonic()<end and not (r/'A13-assisted-drag-tray.stop').exists():time.sleep(.2)
m.record('A13-assisted-drag-tray',wait)
