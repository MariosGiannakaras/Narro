import importlib.util,time
from pathlib import Path
r=Path(__file__).parent
s=importlib.util.spec_from_file_location('capture_boundary',r/'capture-helper-boundary.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def wait():
 end=time.monotonic()+700
 while time.monotonic()<end and not (r/'B5-real-boundaries.stop').exists():time.sleep(.2)
m.record('B5-real-boundaries',wait)
