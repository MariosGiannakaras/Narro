from pathlib import Path
import ctypes,json,datetime,sys
u=ctypes.windll.user32
u.GetWindowLongW.argtypes=[ctypes.c_void_p,ctypes.c_int];u.GetForegroundWindow.restype=ctypes.c_void_p
class R(ctypes.Structure):_fields_=[('left',ctypes.c_long),('top',ctypes.c_long),('right',ctypes.c_long),('bottom',ctypes.c_long)]
h=int(sys.argv[1]);r=R();assert u.GetWindowRect(ctypes.c_void_p(h),ctypes.byref(r))
x={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'label':sys.argv[2],'hwnd':h,'bounds':[r.left,r.top,r.right,r.bottom],'dpi':u.GetDpiForWindow(ctypes.c_void_p(h)),'topmostStyle':bool(u.GetWindowLongW(ctypes.c_void_p(h),-20)&8),'foregroundHwnd':u.GetForegroundWindow()}
with (Path(__file__).parent/'native-window-probes.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(x)+'\n')
print(json.dumps(x))
