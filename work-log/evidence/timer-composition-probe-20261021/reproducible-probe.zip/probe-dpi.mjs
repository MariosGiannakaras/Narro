import fs from 'node:fs';import assert from 'node:assert/strict';
const r='E:/SystemFiles/Desktop/Narro-Workspace/Narro-Timer-Composition-20261021/';const {instance}=await WebAssembly.instantiate(fs.readFileSync(r+'candidate.wasm'),{});const p=instance.exports;
const expected=[10,10,20,20,10,10,20,20,30,30,40,40,30,30,40,40];assert.deepEqual(expected.map((_,i)=>p.dpi_sample(4,4,i)),expected);
assert.equal(p.dpi_sample(4,5,0),999);assert.equal(p.dpi_sample(0,2,0),999);assert.equal(p.dpi_sample(2,0,0),999);
const result={uniformDpiGridAssertions:16,rejectedGeometryAssertions:3,result:'PASS; pure production Rust composition, not native Windows capture/COM'};fs.writeFileSync(r+'dpi-result.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
