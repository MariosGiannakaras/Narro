import fs from 'node:fs'; import assert from 'node:assert/strict';import crypto from 'node:crypto';
const root=new URL('./',import.meta.url);const read=n=>fs.readFileSync(new URL(n,root));const hash=b=>crypto.createHash('sha256').update(b).digest('hex');const p=JSON.parse(read('provenance.json'));
for(const kind of ['baseline','candidate']){assert.equal(hash(read(kind+'.wasm')),p[kind+'WasmSha256']);assert.equal(hash(read(kind+'-production.rs')),p[kind+'SourceSha256']);}
const old=(await WebAssembly.instantiate(read('baseline.wasm'),{})).instance.exports;
assert.deepEqual([old.sample(1,5,0),old.sample(1,5,1)],[5,120]);assert.deepEqual([old.sample(0,5,0),old.sample(0,5,1)],[45,160]);
const now=(await WebAssembly.instantiate(read('candidate.wasm'),{})).instance.exports;
for(let step=1;step<10;step++){assert.deepEqual([now.sample(1,step,0),now.sample(1,step,1)],[10,100]);assert.deepEqual([now.sample(0,step,0),now.sample(0,step,1)],[10,100]);}
assert.deepEqual([now.sample(1,0,0),now.sample(1,10,2),now.sample(0,0,2),now.sample(0,10,0)],[0,240,240,80]);
assert.deepEqual([...Array(16)].map((_,i)=>now.dpi_sample(4,4,i)),[10,10,20,20,10,10,20,20,30,30,40,40,30,30,40,40]);
for(const [w,h]of[[4,5],[0,2],[2,0]])assert.equal(now.dpi_sample(w,h,0),999);
assert.deepEqual([now.normalized_shrink(0),now.normalized_shrink(1)],[10,100]);
console.log('Source/WASM hashes verified; baseline observed RED and candidate 61 composition arithmetic assertions PASS. Native Windows/COM freshness NOT RUN.');
