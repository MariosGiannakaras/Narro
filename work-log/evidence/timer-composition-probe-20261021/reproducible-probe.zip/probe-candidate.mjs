import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';
const root='E:/SystemFiles/Desktop/Narro-Workspace/Narro-Timer-Composition-20261021/';
const {instance}=await WebAssembly.instantiate(fs.readFileSync(root+'candidate.wasm'),{});const sample=instance.exports.sample;
for(let step=1;step<10;step++){assert.deepEqual([sample(1,step,0),sample(1,step,1)],[10,100]);assert.deepEqual([sample(0,step,0),sample(0,step,1)],[10,100]);}
assert.equal(sample(1,0,0),0);assert.equal(sample(1,10,2),240);assert.equal(sample(0,0,2),240);assert.equal(sample(0,10,0),80);
const result={sourceSha256:crypto.createHash('sha256').update(fs.readFileSync('src-tauri/src/focus_mode_raster.rs')).digest('hex'),progressStepsPerDirection:9,midpointScalarAssertions:36,endpointAssertions:4,result:'PASS: actual production composition arithmetic only; no Windows/COM/native freshness proof'};
fs.writeFileSync(root+'candidate-result.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
