#![allow(dead_code)]
extern crate self as tauri;
#[derive(Clone, Copy)]
pub struct PhysicalSize<T> { pub width:T, pub height:T }
impl<T> PhysicalSize<T> { pub fn new(width:T,height:T)->Self { Self{width,height} } }
mod error {
 #[derive(Debug)] pub struct CommandError;
 pub type CommandResult<T> = Result<T,CommandError>;
 impl CommandError { pub fn new(_: &'static str,_: impl Into<String>) -> Self { Self } }
}
mod timer_region { pub const FOCUS_HOST_WIDTH_LOGICAL:f64=340.0; }
#[path="C:/Users/MariosG/.codex/worktrees/m7-native-paint/NarroUpload/src-tauri/src/focus_mode_raster.rs"]
mod production;
fn image(colors:&[u8])->production::Image {
 production::Image{size:PhysicalSize::new(1,colors.len() as u32),bgra:colors.iter().flat_map(|c|[*c,*c,*c,255]).collect()}
}
#[no_mangle]
pub extern "C" fn sample(growing:u32,step:u32,row:u32)->u32 {
 let (old,new)=if growing!=0 {(image(&[0]),image(&[10,100,240]))}else{(image(&[10,100,240]),image(&[80]))};
 let h=if step==0 {old.size.height}else if step==10 {new.size.height}else{2};
 let pixels=production::compose(&old,&new,PhysicalSize::new(1,h),f64::from(step)/10.0).unwrap();
 u32::from(pixels[row as usize*4])
}
#[no_mangle]
pub extern "C" fn dpi_sample(width:u32,height:u32,pixel:u32)->u32 {
 let image=production::Image{size:PhysicalSize::new(2,2),bgra:vec![10,10,10,255,20,20,20,255,30,30,30,255,40,40,40,255]};
 match production::compose(&image,&image,PhysicalSize::new(width,height),0.5){Ok(v)=>u32::from(v[pixel as usize*4]),Err(_)=>999}
}
#[no_mangle]
pub extern "C" fn normalized_shrink(row:u32)->u32 {
 let outgoing=image(&[10,100,240]);
 let incoming=production::Image{size:PhysicalSize::new(4,4),bgra:[80,80,80,255].repeat(16)};
 let frame=production::compose(&outgoing,&incoming,PhysicalSize::new(1,2),0.5).unwrap();u32::from(frame[row as usize*4])
}
