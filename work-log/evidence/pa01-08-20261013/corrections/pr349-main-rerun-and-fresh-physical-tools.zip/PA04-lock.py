"""Physical input only when an owned profile and fresh foreground HWND are verified.
Usage: PA04-lock.py <fresh-main-HWND> <Add-client-x> <Add-client-y>.
No database writes; four-second exclusive transaction is rolled back.
"""
import sqlite3,threading,pathlib,datetime,json,time,subprocess,sys,ctypes,os
r=pathlib.Path(__file__).parent.resolve();events=[];ready=threading.Event();errors=[]
assert len(sys.argv)==4, 'Fresh HWND and observed Add client coordinates required'
hwnd,x,y=map(int,sys.argv[1:])
profile=pathlib.Path.home()/'AppData/Roaming/com.mariosg.Narro'
assert json.loads((profile/'pa-owned-profile.json').read_text())['sessionRoot']==str(r)
assert json.loads((r/'profile-protection-private.json').read_text())['state']=='OWNED_PROFILE_ACTIVE'
u=ctypes.windll.user32;u.GetForegroundWindow.restype=ctypes.c_void_p
assert u.IsWindow(ctypes.c_void_p(hwnd)) and u.GetForegroundWindow()==hwnd, 'Fresh Main HWND must be foreground'
title=ctypes.create_unicode_buffer(100);u.GetWindowTextW(ctypes.c_void_p(hwnd),title,100)
assert title.value=='Narro', 'Expected actual Narro main'
def event(s):events.append({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':s})
def lock():
 db=None
 try:
  db=sqlite3.connect(str(profile/'narro.db'),timeout=2)
  assert db.execute('pragma journal_mode').fetchone()[0]=='delete', 'Exclusive-lock protocol requires DELETE journal'
  db.execute('BEGIN EXCLUSIVE');event('BEGIN EXCLUSIVE acquired; no data statements');ready.set();time.sleep(4)
 except Exception as error:errors.append(str(error));ready.set()
 finally:
  if db:db.rollback();db.close()
  event('rollback/close')
p=subprocess.Popen([sys.executable,str(r/'uia_focus_probe.py'),'PA04-native-focus-during-pending','8',str(hwnd)],creationflags=0x08000000)
time.sleep(.7);t=threading.Thread(target=lock);t.start()
try:
 assert ready.wait(3) and not errors, errors or 'Lock was not acquired'
 env=dict(os.environ,NARRO_PA_INPUT_NO_SNAPSHOT='1')
 for args in [('click','Narro','PA04-real-pending-add',str(x),str(y)),('key','Narro','PA04-real-pending-escape','0x1b'),('key','Narro','PA04-real-pending-tab','0x09'),('key','Narro','PA04-real-pending-shift-tab','0x10+0x09')]:
  assert u.GetForegroundWindow()==hwnd, 'Main lost foreground; abort input'
  event('input start '+args[2]);subprocess.run([sys.executable,str(r/'native-input.py'),*args],check=True,env=env);event('input completed '+args[2])
finally:
 t.join();p.wait(timeout=12);(r/'observations/PA04-lock-events.json').write_text(json.dumps({'events':events,'errors':errors,'freshMainHwnd':hwnd},indent=2)+'\n',encoding='utf-8')
assert not errors,errors
print(json.dumps(events))
