import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
const label = process.argv[2];
const root = 'E:/SystemFiles/Desktop/Narro-PA-session-20261013';
const profile = `${root}/regression-edge-${label}-${Date.now()}`;
const result = spawnSync('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', [
  '--headless', '--disable-gpu', '--no-first-run', `--user-data-dir=${profile}`,
  '--virtual-time-budget=5000', '--dump-dom',
  'http://127.0.0.1:1420/reports-fixture.html?mode=sessions-add-keyboard',
], { windowsHide: true, encoding: 'utf8', timeout: 30000, maxBuffer: 10*1024*1024 });
fs.writeFileSync(`${root}/analysis/F29-regression-${label}.html`, result.stdout ?? '');
fs.writeFileSync(`${root}/analysis/F29-regression-${label}.log`, result.stderr ?? '');
const html = result.stdout ?? '';
const error = html.match(/data-reports-fixture-error="([^"]+)"/)?.[1];
const pass = html.includes('data-reports-add-keyboard-pass="true"');
console.log(JSON.stringify({label, status:result.status, bytes:html.length, pass, error, processError:result.error?.message}));
if (result.status !== 0 || !pass) process.exitCode = 1;
