import sys,pathlib,json,datetime
root_path=pathlib.Path(__file__).parent
sys.path.insert(0,str(root_path/'probe-deps'))
sys.coinit_flags=0
import comtypes.client
mod=comtypes.client.GetModule('UIAutomationCore.dll')
automation=comtypes.client.CreateObject(mod.CUIAutomation,interface=mod.IUIAutomation)
root=automation.ElementFromHandle(int(sys.argv[1]))
assert root.CurrentName.startswith('OBS '), 'Only the observed OBS window is permitted'
expected=sys.argv[2]
assert expected in ('Start Recording','Stop Recording'), 'Only local recorder control is permitted'
nodes=root.FindAll(4,automation.CreateTrueCondition())
matches=[nodes.GetElement(index) for index in range(nodes.Length) if nodes.GetElement(index).CurrentName==expected and nodes.GetElement(index).CurrentControlType==50000]
assert len(matches)==1, 'Recorder control must be unique in fresh native UIA'
button=matches[0]
assert button.CurrentIsEnabled and not button.CurrentIsOffscreen
button.GetCurrentPattern(10000).QueryInterface(mod.IUIAutomationInvokePattern).Invoke()
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hwnd':int(sys.argv[1]),'invoked':expected}))
