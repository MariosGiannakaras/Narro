param([Parameter(Mandatory)][string]$SessionName,[ValidateSet('normal','reduced')][string]$Motion='normal')
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$true
$sessionRoot=Split-Path -Parent $PSCommandPath
$out=Join-Path $sessionRoot $Motion
if(Test-Path -LiteralPath $out){throw 'Do not overwrite an acquisition'}
New-Item -ItemType Directory -Path $out | Out-Null
$serial=0
function Invoke-CaptureCli([string[]]$CliArgs) {
    $script:serial++
    $result = & npx --yes --package '@playwright/cli' playwright-cli "-s=$SessionName" @CliArgs 2>&1
    $resultText=($result | Out-String)
    [IO.File]::WriteAllText((Join-Path $out ('cli-{0:D2}.txt' -f $script:serial)),$resultText)
    return $resultText
}
function Write-CaptureAction([string]$Action) {
    @{utc=[DateTime]::UtcNow.ToString('o');action=$Action} | ConvertTo-Json -Compress | Add-Content -LiteralPath (Join-Path $out 'actions.jsonl')
}
$motionValue=if($Motion -eq 'reduced'){'reduce'}else{'no-preference'}
Invoke-CaptureCli -CliArgs @('run-code',"await page.emulateMedia({ reducedMotion: '$motionValue' });") | Out-Null
Invoke-CaptureCli -CliArgs @('--raw','eval','() => ({reduced:matchMedia("(prefers-reduced-motion: reduce)").matches,viewport:[innerWidth,innerHeight]})') | Set-Content -LiteralPath (Join-Path $out 'media.json')
$startInfo=[Diagnostics.ProcessStartInfo]::new()
$startInfo.FileName=(Get-Command ffmpeg).Source
$startInfo.UseShellExecute=$false
$startInfo.CreateNoWindow=$true
$startInfo.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
$startInfo.RedirectStandardInput=$true
$startInfo.RedirectStandardError=$true
foreach($arg in @('-hide_banner','-loglevel','warning','-f','lavfi','-i','ddagrab=output_idx=0:framerate=60:draw_mouse=1','-vf','hwdownload,format=bgra','-t','180','-c:v','libx264','-preset','ultrafast','-crf','18','-pix_fmt','yuv420p',(Join-Path $out 'native-original.mkv'))){$startInfo.ArgumentList.Add($arg)}
$recorder=[Diagnostics.Process]::new();$recorder.StartInfo=$startInfo
$recorderStarted=$false;$stderrTask=$null
try {
    if(-not $recorder.Start()){throw 'Recorder did not start'}
    $recorderStarted=$true
    $stderrTask=$recorder.StandardError.ReadToEndAsync()
    Write-CaptureAction 'RECORDER_STARTED; actions below are CDP WebView2 inputs, not OS input'
    Start-Sleep -Milliseconds 500
    if($recorder.HasExited){throw 'Recorder exited before interactions'}
    foreach($step in @(
        @{label='Compact view';presentation='timerCompact'},
        @{label='Expand Floating Timer';presentation='timerExpanded'},
        @{label='Collapse Floating Timer';presentation='timerCompact'},
        @{label='Return to Focus Panel';presentation='panel'}
    )) {
        $snapshot=Invoke-CaptureCli -CliArgs @('snapshot')
        $targetRefs=[regex]::Matches($snapshot,('- button "'+[regex]::Escape($step.label)+'"[^\r\n]*\[ref=(e\d+)\]'))
        if($targetRefs.Count -ne 1){throw "Expected one current target $($step.label), found $($targetRefs.Count)"}
        Write-CaptureAction ('BEGIN '+$step.label)
        Invoke-CaptureCli -CliArgs @('click',$targetRefs[0].Groups[1].Value) | Out-Null
        $state=Invoke-CaptureCli -CliArgs @('--raw','eval','() => ({presentation:document.querySelector("[data-focus-surface-coordinator]")?.dataset.focusPresentation,pending:document.querySelector("[data-focus-surface-coordinator]")?.dataset.focusTransitionPending,resizePending:document.querySelector("[data-floating-timer]")?.dataset.floatingResizePending})')
        Write-CaptureAction ('RETURN '+$step.label+'; DOM receipt '+$state.Trim())
        # Receipt describes reached state only. Video/native bounds own acceptance.
        if(($state | ConvertFrom-Json).presentation -ne $step.presentation){throw "Target presentation not reached: $($step.presentation)"}
    }
    Write-CaptureAction 'FOUR TRANSITIONS ACQUIRED; NO VISUAL PASS CLAIM'
} finally {
    if($recorderStarted -and -not $recorder.HasExited){
        $recorder.StandardInput.WriteLine('q');$recorder.StandardInput.Flush()
        if(-not $recorder.WaitForExit(5000)){$recorder.Kill();$recorder.WaitForExit();Write-CaptureAction 'RECORDER_FORCED_STOP; inspect finalization'}
    }
    if($stderrTask){[IO.File]::WriteAllText((Join-Path $out 'recorder-stderr.txt'),$stderrTask.Result)}
    Write-CaptureAction 'RECORDER_STOPPED'
    $recorder.Dispose()
}
& ffprobe -v error -count_frames -show_entries 'stream=width,height,nb_read_frames,r_frame_rate:format=duration' -of json (Join-Path $out 'native-original.mkv') | Set-Content -LiteralPath (Join-Path $out 'video-metadata.json')
