import fs from 'node:fs';import assert from 'node:assert/strict';import crypto from 'node:crypto';const p=JSON.parse(fs.readFileSync(new URL('./provenance.json',import.meta.url)));const bytes=fs.readFileSync(new URL('./candidate.wasm',import.meta.url));assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),p.wasmSha256);const now=(await WebAssembly.instantiate(bytes,{})).instance.exports;for(const name of p.unitBodies)now[name]();
for(let step=1;step<10;step++){assert.deepEqual([now.sample(1,step,0),now.sample(1,step,1)],[10,100]);assert.deepEqual([now.sample(0,step,0),now.sample(0,step,1)],[10,100]);}
assert.deepEqual([now.sample(1,0,0),now.sample(1,10,2),now.sample(0,0,2),now.sample(0,10,0)],[0,240,240,80]);
assert.deepEqual([...Array(16)].map((_,i)=>now.dpi_sample(4,4,i)),[10,10,20,20,10,10,20,20,30,30,40,40,30,30,40,40]);
for(const [w,h]of[[4,5],[0,2],[2,0]])assert.equal(now.dpi_sample(w,h,0),999);
assert.deepEqual([now.normalized_shrink(0),now.normalized_shrink(1)],[10,100]);
console.log('Exact77a6b139 actual production arithmetic61assertions plus6unchanged Rust unit bodies PASS in WASM. Native Windows/COM tests NOT RUN locally.');
