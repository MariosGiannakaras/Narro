import importlib.util,time
from pathlib import Path
p=Path(__file__).parent;sp=importlib.util.spec_from_file_location('c',p/'capture-helper.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
def run():
 c.journal('CASE_BEGIN',case='A13',input='actual @oai/sky Windows keyboard; fresh UIA')
 deadline=time.monotonic()+110
 while not (p/'native-keys-done.flag').exists() and time.monotonic()<deadline:time.sleep(.2)
c.record('A12A13-native-global-keys',run);print('Native-key segment frozen',flush=True)
