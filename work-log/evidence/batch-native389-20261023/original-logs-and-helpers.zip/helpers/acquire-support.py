import importlib.util,re,json,time,subprocess
from pathlib import Path
p=Path(__file__).parent;sp=importlib.util.spec_from_file_location('c',p/'capture-helper.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c);c.serial=100
c.cli('run-code','async(page)=>{await page.emulateMedia({reducedMotion:"no-preference"});}')
def controls():
 c.journal('CASE_BEGIN',case='A09');c.button('Add subtask for Weekly recurring parent',keyboard=True);s=c.cli('snapshot');m=re.findall(r'- textbox(?: "[^"\n]*")?[^\r\n]*\[ref=(e\d+)\]',s)
 if len(m)!=1:raise RuntimeError('Expected single actual subtask entry')
 c.cli('fill',m[0],'Native capture subtask');c.cli('press','Enter');c.cli('snapshot');c.button('Compact view');c.button('Expand Floating Timer');c.button('Notes',keyboard=True);c.button('Open larger notes editor',keyboard=True);s=c.cli('snapshot');m=re.findall(r'textbox "Task note"[^\r\n]*\[ref=(e\d+)\]',s)
 if len(m)!=1:raise RuntimeError('Expected Task note')
 c.cli('fill',m[0],'Owned capture note: actual larger editor and keyboard return.');c.cli('press','Escape');c.button('Save note',keyboard=True);c.button('Notes',keyboard=True);c.cli('snapshot');c.journal('CASE_ACQUIRED_UNREVIEWED',case='A09')
def rapid():
 c.journal('CASE_BEGIN',case='A10');c.button('Collapse Floating Timer');c.cli('snapshot');c.cli('run-code','async(page)=>{for(let i=0;i<3;i++){await page.getByRole("button",{name:"Expand Floating Timer",exact:true}).click({clickCount:3,delay:25});await page.waitForTimeout(700);await page.getByRole("button",{name:"Collapse Floating Timer",exact:true}).click({clickCount:3,delay:25});await page.waitForTimeout(700);}}');c.cli('snapshot');c.journal('CASE_ACQUIRED_UNREVIEWED',case='A10')
def bottom():
 c.journal('CASE_BEGIN',case='A11');c.geometry(lambda a:(a.right-350,a.bottom-114));c.button('Expand Floating Timer');c.geometry();c.cli('snapshot');c.button('Collapse Floating Timer');c.geometry();c.journal('CASE_ACQUIRED_UNREVIEWED',case='A11',limit='diagnostic native placement, not OSdrag')
for label,fn in [('A09-controls-notes-subtask',controls),('A10-rapid-input',rapid),('A11-bottom-edge',bottom)]:
 try:c.record(label,fn);print(label+' input sequence acquired',flush=True)
 except Exception as e:
  (p/(label+'-attempt.json')).write_text(json.dumps({'error':str(e),'verdict':'NOT ANALYZED','next':'independent group only; recover state if required'},indent=2));print(label+' incomplete: '+str(e),flush=True);break
