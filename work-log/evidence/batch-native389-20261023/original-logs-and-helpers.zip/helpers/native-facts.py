import ctypes,json
u=ctypes.windll.user32;g=ctypes.windll.gdi32
class R(ctypes.Structure):_fields_=[('left',ctypes.c_long),('top',ctypes.c_long),('right',ctypes.c_long),('bottom',ctypes.c_long)]
out=[]
@ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
def visit(h,l):
 p=ctypes.c_ulong();u.GetWindowThreadProcessId(ctypes.c_void_p(h),ctypes.byref(p))
 if p.value==42584:
  t=ctypes.create_unicode_buffer(512);cl=ctypes.create_unicode_buffer(256);u.GetWindowTextW(ctypes.c_void_p(h),t,512);u.GetClassNameW(ctypes.c_void_p(h),cl,256);b=R();u.GetWindowRect(ctypes.c_void_p(h),ctypes.byref(b));out.append({'hwnd':h,'title':t.value,'class':cl.value,'bounds':[b.left,b.top,b.right,b.bottom],'visible':bool(u.IsWindowVisible(ctypes.c_void_p(h))),'exStyle':u.GetWindowLongW(ctypes.c_void_p(h),-20),'owner':u.GetWindow(ctypes.c_void_p(h),4),'dpi':u.GetDpiForWindow(ctypes.c_void_p(h))})
 return True
u.EnumWindows(visit,0);print(json.dumps(out))
