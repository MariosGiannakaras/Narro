import importlib.util,subprocess,time,json,ctypes
from pathlib import Path
p=Path(__file__).parent;sp=importlib.util.spec_from_file_location('c',p/'capture-helper.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c);c.serial=400
c.cli('tab-select','0');c.cli('run-code','async(page)=>{await page.emulateMedia({reducedMotion:"no-preference"});}');s=c.cli('snapshot')
if 'button "Compact view"' in s:c.button('Compact view')
edge=Path(r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe');assert edge.is_file()
def run():
 c.journal('CASE_BEGIN',case='A14',limit='current primary96DPI only; hardware and125DPI not exercised')
 for mode in ['--start-maximized','--start-fullscreen']:
  proc=subprocess.Popen([str(edge),'--app='+ (p/'backdrop.html').as_uri(),mode,'--user-data-dir='+str(p/('edge-owned-'+mode[2:])),'--no-first-run','--no-default-browser-check'],creationflags=0x08000000)
  try:
   c.journal('OWNED_BACKDROP_LAUNCHED',mode=mode,pid=proc.pid);time.sleep(7);c.journal('NARRO_NATIVE_OVER_BACKDROP',mode=mode,windows=json.loads(subprocess.check_output(['python',str(p/'native-facts.py')],text=True)));time.sleep(3)
  finally:
   if proc.poll() is None:proc.terminate();proc.wait(timeout=10)
 c.journal('CASE_ACQUIRED_UNREVIEWED',case='A14',limit='startup fullscreen request actual desktop movie; no exclusive mode or hardware/DPI PASS')
c.record('A14-topmost-backdrops',run);print('A14 available primary-display backdrop acquisition frozen',flush=True)
