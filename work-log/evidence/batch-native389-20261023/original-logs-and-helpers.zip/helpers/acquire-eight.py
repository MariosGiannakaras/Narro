import importlib.util,json,subprocess,time
from pathlib import Path
p=Path(__file__).parent;sp=importlib.util.spec_from_file_location('c',p/'capture-helper.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c);c.serial=10
c.cli('--raw','eval','async()=>{await window.__TAURI_INTERNALS__.invoke("focus_surface_show");return true;}')
for motion,start in [('no-preference',1),('reduce',5)]:
 c.cli('run-code','async(page)=>{await page.emulateMedia({reducedMotion:'+json.dumps(motion)+'});}');c.cli('--raw','eval','()=>({reduced:matchMedia("(prefers-reduced-motion: reduce)").matches,presentation:document.querySelector("[data-focus-surface-coordinator]")?.dataset.focusPresentation})')
 def run():
  for offset,name in enumerate(['Compact view','Expand Floating Timer','Collapse Floating Timer','Return to Focus Panel']):
   case='A'+str(start+offset).zfill(2);c.journal('CASE_BEGIN',case=case,motion=motion);facts=json.loads(subprocess.check_output(['python',str(p/'native-facts.py')],text=True));c.journal('HWND_BEFORE',case=case,windows=facts);c.button(name);time.sleep(.8);state=c.cli('--raw','eval','()=>({presentation:document.querySelector("[data-focus-surface-coordinator]")?.dataset.focusPresentation,pending:document.querySelector("[data-focus-surface-coordinator]")?.dataset.focusTransitionPending,resizePending:document.querySelector("[data-floating-timer]")?.dataset.floatingResizePending})');c.journal('CASE_ACQUIRED_UNREVIEWED',case=case,projection=state,windows=json.loads(subprocess.check_output(['python',str(p/'native-facts.py')],text=True)))
 c.record('A01-04-normal' if start==1 else 'A05-08-reduced',run);print('Acquired4transition inputs motion='+motion,flush=True)
print('8/8 transition acquisition finished; no physical PASS analysis',flush=True)
