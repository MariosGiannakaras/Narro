import importlib.util,re,json
from pathlib import Path
p=Path(__file__).parent;sp=importlib.util.spec_from_file_location('c',p/'capture-helper.py');c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c);c.serial=320
s=c.cli('snapshot');m=re.findall(r'generic "Show Floating Timer actions"[^\r\n]*\[ref=(e\d+)\]',s)
if len(m)==1:c.cli('hover',m[0])
c.button('Return to Focus Panel');
def run():
 c.journal('CASE_BEGIN',case='A12');s=c.cli('snapshot');a=re.findall(r'- article \[ref=(e\d+)\]',s)
 if not a:raise RuntimeError('Expected live task card')
 c.cli('hover',a[0]);c.button('Resume',keyboard=True);c.button('Home');c.cli('tab-select','1');c.cli('snapshot');c.journal('HOME_EXIT_ACQUIRED_UNREVIEWED',case='A12',next='native global-key reentry segment')
c.record('A12-home-pause-exit',run);print('A12 Home segment acquired; native reentry next',flush=True)
