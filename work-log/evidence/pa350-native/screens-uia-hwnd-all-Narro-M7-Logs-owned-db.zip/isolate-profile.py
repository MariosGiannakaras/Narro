from pathlib import Path
import json,datetime,hashlib,shutil,subprocess
r=Path(__file__).resolve().parent;old=Path(r'E:\SystemFiles\Desktop\Narro-PA-postfix-20261013')
assert json.loads((r/'session-meta.json').read_text(encoding='utf-8-sig'))['state']=='ARTIFACT_VERIFIED', 'Verify actual exact CI executable before profile mutation'
running=subprocess.check_output(['powershell','-NoLogo','-NoProfile','-Command',"@(Get-Process narro,narro-m7-validation -ErrorAction SilentlyContinue | Select-Object Id,ProcessName) | ConvertTo-Json -Compress"],encoding='utf8',creationflags=0x08000000);assert not json.loads(running or '[]')
prior=json.loads((old/'profile-protection-private.json').read_text());assert prior['state']=='ORIGINAL_PROFILES_RESTORED'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S');items=[]
for item in prior['namespaces']:
 base=(Path.home()/'AppData'/item['kind']).resolve();active=base/'com.mariosg.Narro';retained=Path(item['retainedPostfix']);protected=base/('com.mariosg.Narro.PA350-protected-'+stamp)
 assert active.parent==base and retained.resolve().parent==base and protected.parent==base
 assert active.is_dir() and retained.is_dir() and not active.is_symlink() and not retained.is_symlink() and not protected.exists()
 marker=json.loads((retained/'pa-owned-profile.json').read_text());assert marker['owned'] and marker['sessionRoot']==str(old)
 items.append({'kind':item['kind'],'active':str(active),'retained':str(retained),'protected':str(protected)})
actual=hashlib.sha256((Path(items[0]['active'])/'narro.db').read_bytes()).hexdigest();assert actual==json.loads((r/'current-original-baseline-private.json').read_text())['currentOriginalDbSha256'],'Current personal profile changed after its fresh backup'
ledger={'sessionRoot':str(r),'originalDbSha256':actual,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'PREPARED','namespaces':items};p=r/'profile-protection-private.json';assert not p.exists();p.write_text(json.dumps(ledger,indent=2),encoding='utf8')
for item in items:
 active=Path(item['active']);active.rename(item['protected']);ledger['state']='ORIGINAL_PROTECTED_'+item['kind'];p.write_text(json.dumps(ledger,indent=2),encoding='utf8')
 if item['kind']=='Roaming':shutil.copytree(item['retained'],active)
 else:active.mkdir() # Fresh owned WebView cache, preserve original Local namespace.
 (active/'pa-owned-profile.json').write_text(json.dumps({'sessionRoot':str(r),'owned':True,'utc':ledger['utc']}),encoding='utf8')
ledger['state']='OWNED_PROFILE_ACTIVE';p.write_text(json.dumps(ledger,indent=2),encoding='utf8');print(json.dumps({'state':ledger['state'],'originalDbSha256':actual}))
