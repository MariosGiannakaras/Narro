import{l as i,k as n}from"./diagnosticApi-DGcZU1ym.js";const a="board-data-invalidated";async function r(){try{await n(a)}catch{}}function d(t){return i(a,()=>t())}export{r as e,d as l};
