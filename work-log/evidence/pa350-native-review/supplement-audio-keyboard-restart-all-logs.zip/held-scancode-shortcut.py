import ctypes as c, ctypes.wintypes as w, json,time,sys,pathlib,datetime
r=pathlib.Path(__file__).parent;u=c.windll.user32;u.GetForegroundWindow.restype=w.HWND
h=int(sys.argv[1]);assert json.loads((r/'profile-protection-private.json').read_text())['state']=='OWNED_PROFILE_ACTIVE'
b=c.create_unicode_buffer(100);u.GetWindowTextW(w.HWND(h),b,100);assert b.value=='Narro - Focus' and int(u.GetForegroundWindow())==h
class KI(c.Structure):_fields_=[('vk',w.WORD),('scan',w.WORD),('flags',w.DWORD),('time',w.DWORD),('extra',c.c_size_t)]
class MI(c.Structure):_fields_=[('x',w.LONG),('y',w.LONG),('data',w.DWORD),('flags',w.DWORD),('time',w.DWORD),('extra',c.c_size_t)]
class UN(c.Union):_fields_=[('ki',KI),('mi',MI)]
class INPUT(c.Structure):_fields_=[('type',w.DWORD),('data',UN)]
events=[]
def send(scan,up=False):
 inp=INPUT(1,UN(ki=KI(0,scan,8|(2 if up else 0),0,0)));assert u.SendInput(1,c.byref(inp),c.sizeof(inp))==1
 events.append({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scan':scan,'up':up,'ctrl':bool(u.GetAsyncKeyState(0x11)&0x8000),'alt':bool(u.GetAsyncKeyState(0x12)&0x8000),'shift':bool(u.GetAsyncKeyState(0x10)&0x8000)})
try:
 send(0x1d);time.sleep(.05);send(0x38);time.sleep(.05);send(0x19);time.sleep(.1)
finally:
 send(0x19,True);time.sleep(.05);send(0x38,True);time.sleep(.05);send(0x1d,True)
(r/'observations/held-scancode-shortcut.json').write_text(json.dumps({'hwnd':h,'chord':'physical Ctrl+Alt+P, no Shift','events':events},indent=2));print(json.dumps(events))
