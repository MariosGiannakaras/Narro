from pathlib import Path
import subprocess,json,re
from PIL import Image,ImageDraw
r=Path(__file__).resolve().parent;src=Path(r'E:\SystemFiles\Desktop\Narro-Workspace\Narro-Pointer-Retry-20261024-065432')
windows=[('board-reorder','pointer-retry-board',145,148,(232,285,1140,360)),('reverse-crosslane','pointer-retry-crosslane-timer',16,19,(232,285,1140,420)),('repeat-reorder','pointer-retry-crosslane-timer',24.5,27.5,(232,285,1140,360)),('forward-crosslane','pointer-retry-crosslane-timer',30,33,(232,285,1140,420)),('outside-drop','pointer-retry-crosslane-timer',40.3,43.3,(232,110,1140,560)),('focus-entry','pointer-retry-crosslane-timer',48,52,(2170,0,390,740)),('compact-switch','pointer-retry-crosslane-timer',58,62,(2170,0,390,740)),('timer-lower-drag','pointer-retry-crosslane-timer',74.4,77.4,(2170,0,390,180)),('timer-edge-drag','pointer-retry-crosslane-timer',90.4,93.4,(2170,0,390,180)),('timer-top-drag','pointer-retry-crosslane-timer',117.8,120.8,(2170,0,390,180))]
summary=[]
for label,name,start,end,crop in windows:
 d=r/('exact-'+label);d.mkdir(exist_ok=True);x,y,w,h=crop
 p=subprocess.run(['ffmpeg','-y','-hide_banner','-threads','2','-ss',str(start),'-i',str(src/name/'native-original.mkv'),'-t',str(end-start),'-vf',f'crop={w}:{h}:{x}:{y},showinfo','-fps_mode','passthrough',str(d/'frame-%04d.png')],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,encoding='utf-8',check=True)
 (d/'ffmpeg-extraction.txt').write_text(p.stderr,encoding='utf-8')
 times=[float(t) for t in re.findall(r'\bn:\s*\d+\s+pts:\s*\d+\s+pts_time:([\d.e+-]+)',p.stderr)]
 fs=sorted(d.glob('frame-*.png'));assert len(fs)<=len(times)<=len(fs)+2,(label,len(fs),len(times));times=times[:len(fs)]
 rows=[{'file':f.name,'pts':round(start+t,6)} for f,t in zip(fs,times)];(d/'index.json').write_text(json.dumps(rows),encoding='utf-8')
 # Canonical sheets use exact extracted frame PTS, never OpenCV time/index seek.
 chosen=[]
 for row in rows:
  if not chosen or row['pts']-chosen[-1]['pts']>=.23:chosen.append(row)
 for page in range(0,len(chosen),8):
  subset=chosen[page:page+8];width=570 if w>500 else 390;height=round(h*width/w);out=Image.new('RGB',(width*2,(height+24)*((len(subset)+1)//2)),'#202020');draw=ImageDraw.Draw(out)
  for j,row in enumerate(subset):
   im=Image.open(d/row['file']).resize((width,height));xx=j%2*width;yy=j//2*(height+24);out.paste(im,(xx,yy+24));draw.text((xx+3,yy+4),f'{label} source PTS {row["pts"]:.3f}s',fill='white')
  out.save(r/f'exact-{label}-page{page//8}.png')
 summary.append({'label':label,'video':name,'start':start,'end':end,'frames':len(rows),'firstPts':rows[0]['pts'],'lastPts':rows[-1]['pts'],'crop':crop})
(r/'exact-extraction-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))
