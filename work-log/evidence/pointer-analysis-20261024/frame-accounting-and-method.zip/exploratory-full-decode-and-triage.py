from pathlib import Path
import subprocess,json,hashlib,cv2,numpy as np
from PIL import Image,ImageDraw
r=Path(__file__).resolve().parent;src=Path(r'E:\SystemFiles\Desktop\Narro-Workspace\Narro-Pointer-Retry-20261024-065432');repo=Path(r'C:\Users\MariosG\.codex\worktrees\m7-native-paint\NarroUpload')
manifest=json.loads(subprocess.check_output(['git','show','HEAD:work-log/evidence/pointer-retry-20261024/SHA256-MANIFEST.json'],cwd=repo))
names=['pointer-retry-board','pointer-retry-crosslane-timer'];verified=[]
for name in names:
 p=src/name/'native-original.mkv';expected=next(x for x in manifest['files'] if x['path']==name+'/native-original.mkv')['gitBlobSha256'];actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==expected
 raw=subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_frames','-show_entries','frame=best_effort_timestamp_time','-of','json',str(p)])
 (r/(name+'-frame-pts.json')).write_bytes(raw);pts=[float(x['best_effort_timestamp_time']) for x in json.loads(raw)['frames']];assert all(b>a for a,b in zip(pts,pts[1:]))
 cap=cv2.VideoCapture(str(p));last=None;changes=[];i=0
 while True:
  ok,frame=cap.read()
  if not ok:break
  small=cv2.resize(frame,(640,270),interpolation=cv2.INTER_AREA);delta=0 if last is None else float(np.abs(small.astype(np.int16)-last.astype(np.int16)).mean());changes.append({'frame':i,'pts':pts[i],'meanPixelDelta640':round(delta,5)});last=small;i+=1
 cap.release();assert i==len(pts)
 (r/(name+'-changes.json')).write_text(json.dumps(changes),encoding='utf-8')
 verified.append({'segment':name,'sha256':actual,'decodedFrames':i,'firstPts':pts[0],'lastPts':pts[-1],'maxPtsGap':max(b-a for a,b in zip(pts,pts[1:]))})
 def sample(t,crop=None):
  cp=cv2.VideoCapture(str(p));cp.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,f=cp.read();cp.release();assert ok,(name,t)
  if crop is not None:x,y,w,h=crop;f=f[y:y+h,x:x+w]
  return Image.fromarray(cv2.cvtColor(f,cv2.COLOR_BGR2RGB))
 def sheet(times,label,crop=None,width=640,cols=2):
  ims=[sample(t,crop) for t in times];height=round(ims[0].height*width/ims[0].width);canvas=Image.new('RGB',(cols*width,((len(ims)+cols-1)//cols)*(height+24)),'#202020');draw=ImageDraw.Draw(canvas)
  for j,(im,t) in enumerate(zip(ims,times)):
   x=(j%cols)*width;y=(j//cols)*(height+24);canvas.paste(im.resize((width,height)),(x,y+24));draw.text((x+4,y+4),f'{name} PTS {t:.3f}s',fill='white')
  canvas.save(r/(label+'.jpg'),quality=94)
 sheet([float(x) for x in range(0,int(pts[-1]),10)],name+'-overview',width=640,cols=2)
 windows=[('reorder-1',145.0,148.0,(232,285,1140,360))] if name==names[0] else [('reverse-crosslane',16,19,(232,285,1140,420)),('reorder-2',24.5,27.5,(232,285,1140,360)),('forward-crosslane',30,33,(232,285,1140,420)),('invalid-drop',40.3,43.3,(232,110,1140,560)),('focus-entry',48,52,(2170,0,390,740)),('compact-switch',58,62,(2170,0,390,740)),('timer-drag-1',74.4,77.4,(2170,0,390,180)),('timer-drag-2',90.4,93.4,(2170,0,390,180)),('timer-drag-3',117.8,120.8,(2170,0,390,180))]
 for label,start,end,crop in windows:
  # Every source frame in the interval is preserved as a numbered lossless ROI.
  dr=r/label;dr.mkdir(exist_ok=True);cp=cv2.VideoCapture(str(p));cp.set(cv2.CAP_PROP_POS_FRAMES,next(k for k,v in enumerate(pts) if v>=start));idx=next(k for k,v in enumerate(pts) if v>=start);rows=[]
  while idx<len(pts) and pts[idx]<=end:
   ok,f=cp.read();assert ok;x,y,w,h=crop;cv2.imwrite(str(dr/f'{idx:06d}.png'),f[y:y+h,x:x+w]);rows.append({'frame':idx,'pts':pts[idx],'file':f'{idx:06d}.png'});idx+=1
  cp.release();(dr/'index.json').write_text(json.dumps(rows),encoding='utf-8')
  sheet(list(np.arange(start,end+.001,.25)),label+'-sequence',crop,width=570 if crop[2]>500 else 390,cols=3)
 (r/(name+'-sample-method.txt')).write_text('Full duration decoded at native recorded frames for PTS accounting and 640px frame-difference triage. Overview sampled each10s; each interaction ROI interval exported losslessly for all recorded frames; navigational sequence sheets250ms apart. These do not prove every DWM refresh or direct Blitzit motion parity. Originals not modified.',encoding='utf-8')
(r/'verified-media.json').write_text(json.dumps(verified,indent=2),encoding='utf-8');print(json.dumps(verified))
